// Telegram Bot Command Handler Library
export interface Product {
  id: string
  name: string
  price: number
  category: string
  image: string
  description: string
  stock: number
}

export interface Order {
  id: string
  total: number
  status: "pending" | "processing" | "completed" | "cancelled"
  items: string[]
  customerInfo?: {
    name?: string
    email?: string
    address?: string
  }
  createdAt: Date
}

export interface Category {
  id: string
  name: string
  description?: string
  image?: string
}

export interface ShopData {
  products: Product[]
  orders: Order[]
  categories: Category[]
}

export class TelegramBotHandler {
  private botToken: string
  private shopData: ShopData

  constructor(botToken: string, shopData: ShopData) {
    this.botToken = botToken
    this.shopData = shopData
  }

  async sendMessage(chatId: number, text: string, parseMode = "Markdown") {
    try {
      const response = await fetch(`https://api.telegram.org/bot${this.botToken}/sendMessage`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          parse_mode: parseMode,
        }),
      })

      return await response.json()
    } catch (error) {
      console.error("Error sending Telegram message:", error)
      throw error
    }
  }

  async sendPhoto(chatId: number, photoUrl: string, caption?: string) {
    try {
      const response = await fetch(`https://api.telegram.org/bot${this.botToken}/sendPhoto`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          chat_id: chatId,
          photo: photoUrl,
          caption,
          parse_mode: "Markdown",
        }),
      })

      return await response.json()
    } catch (error) {
      console.error("Error sending Telegram photo:", error)
      throw error
    }
  }

  async handleCommand(command: string, args: string[], chatId: number): Promise<void> {
    switch (command) {
      case "/start":
      case "/help":
        await this.handleHelpCommand(chatId)
        break

      case "/products":
        await this.handleProductsCommand(chatId, args)
        break

      case "/product":
        await this.handleProductCommand(chatId, args)
        break

      case "/addproduct":
        await this.handleAddProductCommand(chatId, args)
        break

      case "/editproduct":
        await this.handleEditProductCommand(chatId, args)
        break

      case "/deleteproduct":
        await this.handleDeleteProductCommand(chatId, args)
        break

      case "/orders":
        await this.handleOrdersCommand(chatId, args)
        break

      case "/order":
        await this.handleOrderCommand(chatId, args)
        break

      case "/updateorder":
        await this.handleUpdateOrderCommand(chatId, args)
        break

      case "/categories":
        await this.handleCategoriesCommand(chatId)
        break

      case "/addcategory":
        await this.handleAddCategoryCommand(chatId, args)
        break

      case "/status":
        await this.handleStatusCommand(chatId)
        break

      case "/stats":
        await this.handleStatsCommand(chatId)
        break

      case "/search":
        await this.handleSearchCommand(chatId, args)
        break

      case "/lowstock":
        await this.handleLowStockCommand(chatId)
        break

      default:
        await this.handleUnknownCommand(chatId, command)
        break
    }
  }

  private async handleHelpCommand(chatId: number): Promise<void> {
    const helpText = `🤖 *Crypto Shop Bot Commands*

*📦 Product Management:*
/products - List all products
/product [id] - View product details
/addproduct - Add new product (guided)
/editproduct [id] - Edit product
/deleteproduct [id] - Delete product
/lowstock - Show low stock products

*📋 Order Management:*
/orders - List all orders
/order [id] - View order details
/updateorder [id] [status] - Update order status

*🏷️ Categories:*
/categories - List categories
/addcategory [name] - Add category

*📊 Analytics:*
/status - Shop status overview
/stats - Detailed statistics
/search [term] - Search products

*ℹ️ General:*
/help - Show this help message

💡 *Tip:* Use commands without parameters for guided setup!`

    await this.sendMessage(chatId, helpText)
  }

  private async handleProductsCommand(chatId: number, args: string[]): Promise<void> {
    const { products } = this.shopData

    if (products.length === 0) {
      await this.sendMessage(chatId, "📦 *No products found.*\n\nUse /addproduct to add your first product!")
      return
    }

    // Handle pagination
    const page = args.length > 0 ? Number.parseInt(args[0]) || 1 : 1
    const itemsPerPage = 5
    const startIndex = (page - 1) * itemsPerPage
    const endIndex = startIndex + itemsPerPage
    const paginatedProducts = products.slice(startIndex, endIndex)
    const totalPages = Math.ceil(products.length / itemsPerPage)

    let productsText = `📦 *Products (Page ${page}/${totalPages}):*\n\n`

    paginatedProducts.forEach((product, index) => {
      const stockStatus =
        product.stock === 0
          ? "❌ OUT OF STOCK"
          : product.stock < 5
            ? `⚠️ LOW STOCK (${product.stock})`
            : `✅ In Stock (${product.stock})`

      productsText += `*${startIndex + index + 1}. ${product.name}*\n`
      productsText += `🆔 ID: \`${product.id}\`\n`
      productsText += `💰 Price: ${product.price} ETH\n`
      productsText += `📊 ${stockStatus}\n`
      productsText += `🏷️ Category: ${product.category}\n`

      if (product.description) {
        productsText += `📝 ${product.description.substring(0, 50)}${product.description.length > 50 ? "..." : ""}\n`
      }

      productsText += `\n`
    })

    if (totalPages > 1) {
      productsText += `\n📄 Use /products [page] to navigate pages`
    }

    productsText += `\n💡 Use /product [id] for detailed view`

    await this.sendMessage(chatId, productsText)
  }

  private async handleProductCommand(chatId: number, args: string[]): Promise<void> {
    if (args.length === 0) {
      await this.sendMessage(chatId, "❌ Please provide a product ID.\n\nUsage: /product [id]\nExample: /product 123")
      return
    }

    const productId = args[0]
    const product = this.shopData.products.find((p) => p.id === productId)

    if (!product) {
      await this.sendMessage(
        chatId,
        `❌ Product with ID \`${productId}\` not found.\n\nUse /products to see all products.`,
      )
      return
    }

    const stockStatus = product.stock === 0 ? "❌ OUT OF STOCK" : product.stock < 5 ? `⚠️ LOW STOCK` : `✅ In Stock`

    const productText = `📦 *Product Details*

*${product.name}*

🆔 **ID:** \`${product.id}\`
💰 **Price:** ${product.price} ETH
📊 **Stock:** ${product.stock} units ${stockStatus}
🏷️ **Category:** ${product.category}

📝 **Description:**
${product.description || "No description available"}

🔧 **Actions:**
• /editproduct ${product.id} - Edit this product
• /deleteproduct ${product.id} - Delete this product`

    // Send product image if available
    if (product.image && product.image !== "/placeholder.svg" && !product.image.includes("placeholder")) {
      try {
        await this.sendPhoto(chatId, product.image, productText)
      } catch (error) {
        // If image fails, send text only
        await this.sendMessage(chatId, productText)
      }
    } else {
      await this.sendMessage(chatId, productText)
    }
  }

  private async handleAddProductCommand(chatId: number, args: string[]): Promise<void> {
    if (args.length < 4) {
      const guideText = `➕ *Add New Product*

Please provide product information in this format:
\`/addproduct "Product Name" [price] [stock] [category] "Description"\`

**Example:**
\`/addproduct "Digital Art NFT" 0.5 10 Art "Beautiful digital artwork collection"\`

**Parameters:**
• **Name:** Product name (use quotes if it contains spaces)
• **Price:** Price in ETH (e.g., 0.5)
• **Stock:** Number of items available
• **Category:** Product category
• **Description:** Product description (optional, use quotes)

💡 **Available categories:** ${this.shopData.categories.map((c) => c.name).join(", ")}`

      await this.sendMessage(chatId, guideText)
      return
    }

    try {
      // Parse arguments - handle quoted strings
      const fullText = args.join(" ")
      const matches = fullText.match(/"([^"]+)"|(\S+)/g) || []
      const cleanArgs = matches.map((arg) => arg.replace(/"/g, ""))

      if (cleanArgs.length < 4) {
        throw new Error("Insufficient arguments")
      }

      const [name, priceStr, stockStr, category, ...descriptionParts] = cleanArgs
      const price = Number.parseFloat(priceStr)
      const stock = Number.parseInt(stockStr)
      const description = descriptionParts.join(" ")

      if (isNaN(price) || price <= 0) {
        await this.sendMessage(chatId, "❌ Invalid price. Please enter a valid number greater than 0.")
        return
      }

      if (isNaN(stock) || stock < 0) {
        await this.sendMessage(chatId, "❌ Invalid stock. Please enter a valid number 0 or greater.")
        return
      }

      // Check if category exists
      const categoryExists = this.shopData.categories.some((c) => c.name.toLowerCase() === category.toLowerCase())

      if (!categoryExists) {
        await this.sendMessage(
          chatId,
          `❌ Category "${category}" not found.\n\nAvailable categories: ${this.shopData.categories.map((c) => c.name).join(", ")}\n\nUse /addcategory to create a new category.`,
        )
        return
      }

      // Create new product
      const newProduct: Product = {
        id: Date.now().toString(),
        name,
        price,
        stock,
        category,
        description,
        image: "/placeholder.svg?height=300&width=300&text=Product",
      }

      // In a real app, you would save to database
      // For demo purposes, we'll just show what would be created
      const successText = `✅ *Product Created Successfully!*

**${newProduct.name}**
🆔 ID: \`${newProduct.id}\`
💰 Price: ${newProduct.price} ETH
📊 Stock: ${newProduct.stock} units
🏷️ Category: ${newProduct.category}
📝 Description: ${newProduct.description}

⚠️ *Demo Mode:* Product would be saved to database in production.

💡 Use /product ${newProduct.id} to view details`

      await this.sendMessage(chatId, successText)
    } catch (error) {
      await this.sendMessage(chatId, "❌ Error creating product. Please check your input format and try again.")
    }
  }

  private async handleOrdersCommand(chatId: number, args: string[]): Promise<void> {
    const { orders } = this.shopData

    if (orders.length === 0) {
      await this.sendMessage(chatId, "📋 *No orders found.*\n\nOrders will appear here when customers make purchases.")
      return
    }

    // Filter by status if provided
    const statusFilter = args.length > 0 ? args[0].toLowerCase() : null
    const validStatuses = ["pending", "processing", "completed", "cancelled"]

    let filteredOrders = orders
    if (statusFilter && validStatuses.includes(statusFilter)) {
      filteredOrders = orders.filter((order) => order.status === statusFilter)
    }

    if (filteredOrders.length === 0) {
      await this.sendMessage(chatId, `📋 No orders found with status: ${statusFilter}`)
      return
    }

    let ordersText = statusFilter ? `📋 *Orders (${statusFilter.toUpperCase()}):*\n\n` : `📋 *All Orders:*\n\n`

    filteredOrders.slice(0, 10).forEach((order) => {
      const statusEmoji =
        {
          pending: "⏳",
          processing: "🔄",
          completed: "✅",
          cancelled: "❌",
        }[order.status] || "❓"

      ordersText += `${statusEmoji} *Order #${order.id}*\n`
      ordersText += `💰 Total: ${order.total} ETH\n`
      ordersText += `📊 Status: ${order.status.toUpperCase()}\n`
      ordersText += `📦 Items: ${order.items.slice(0, 2).join(", ")}${order.items.length > 2 ? "..." : ""}\n`
      ordersText += `📅 Date: ${order.createdAt ? new Date(order.createdAt).toLocaleDateString() : "N/A"}\n\n`
    })

    if (filteredOrders.length > 10) {
      ordersText += `\n... and ${filteredOrders.length - 10} more orders`
    }

    ordersText += `\n💡 Use /order [id] for detailed view`
    ordersText += `\n📊 Filter: /orders [pending|processing|completed|cancelled]`

    await this.sendMessage(chatId, ordersText)
  }

  private async handleStatsCommand(chatId: number): Promise<void> {
    const { products, orders } = this.shopData

    const totalProducts = products.length
    const totalOrders = orders.length
    const pendingOrders = orders.filter((o) => o.status === "pending").length
    const processingOrders = orders.filter((o) => o.status === "processing").length
    const completedOrders = orders.filter((o) => o.status === "completed").length
    const cancelledOrders = orders.filter((o) => o.status === "cancelled").length

    const totalRevenue = orders.filter((o) => o.status === "completed").reduce((sum, o) => sum + o.total, 0)

    const averageOrderValue = completedOrders > 0 ? totalRevenue / completedOrders : 0

    const lowStockProducts = products.filter((p) => p.stock < 5 && p.stock > 0).length
    const outOfStockProducts = products.filter((p) => p.stock === 0).length

    const topCategories = this.shopData.categories
      .map((cat) => ({
        name: cat.name,
        count: products.filter((p) => p.category === cat.id || p.category === cat.name).length,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 3)

    const statsText = `📊 *Detailed Shop Statistics*

**📦 Products:**
• Total Products: ${totalProducts}
• ⚠️ Low Stock: ${lowStockProducts}
• ❌ Out of Stock: ${outOfStockProducts}

**📋 Orders:**
• Total Orders: ${totalOrders}
• ⏳ Pending: ${pendingOrders}
• 🔄 Processing: ${processingOrders}
• ✅ Completed: ${completedOrders}
• ❌ Cancelled: ${cancelledOrders}

**💰 Revenue:**
• Total Revenue: ${totalRevenue.toFixed(4)} ETH
• Average Order: ${averageOrderValue.toFixed(4)} ETH

**🏷️ Top Categories:**
${topCategories.map((cat, i) => `${i + 1}. ${cat.name} (${cat.count} products)`).join("\n")}

**📈 Performance:**
• Completion Rate: ${totalOrders > 0 ? ((completedOrders / totalOrders) * 100).toFixed(1) : 0}%
• Active Products: ${products.filter((p) => p.stock > 0).length}

🎯 Keep up the excellent work!`

    await this.sendMessage(chatId, statsText)
  }

  private async handleLowStockCommand(chatId: number): Promise<void> {
    const lowStockProducts = this.shopData.products.filter((p) => p.stock < 5)

    if (lowStockProducts.length === 0) {
      await this.sendMessage(
        chatId,
        "✅ *All products are well stocked!*\n\nNo products with low stock (< 5 units) found.",
      )
      return
    }

    let lowStockText = `⚠️ *Low Stock Alert*\n\nProducts with less than 5 units:\n\n`

    lowStockProducts.forEach((product) => {
      const stockEmoji = product.stock === 0 ? "❌" : "⚠️"
      lowStockText += `${stockEmoji} *${product.name}*\n`
      lowStockText += `📊 Stock: ${product.stock} units\n`
      lowStockText += `💰 Price: ${product.price} ETH\n`
      lowStockText += `🆔 ID: \`${product.id}\`\n\n`
    })

    lowStockText += `💡 Consider restocking these items soon!`

    await this.sendMessage(chatId, lowStockText)
  }

  private async handleSearchCommand(chatId: number, args: string[]): Promise<void> {
    if (args.length === 0) {
      await this.sendMessage(
        chatId,
        "🔍 Please provide a search term.\n\nUsage: /search [term]\nExample: /search digital art",
      )
      return
    }

    const searchTerm = args.join(" ").toLowerCase()
    const matchingProducts = this.shopData.products.filter(
      (product) =>
        product.name.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm),
    )

    if (matchingProducts.length === 0) {
      await this.sendMessage(
        chatId,
        `🔍 No products found matching "${searchTerm}".\n\nTry different keywords or use /products to see all products.`,
      )
      return
    }

    let searchText = `🔍 *Search Results for "${searchTerm}":*\n\nFound ${matchingProducts.length} product(s):\n\n`

    matchingProducts.slice(0, 5).forEach((product) => {
      searchText += `📦 *${product.name}*\n`
      searchText += `🆔 ID: \`${product.id}\`\n`
      searchText += `💰 Price: ${product.price} ETH\n`
      searchText += `📊 Stock: ${product.stock}\n\n`
    })

    if (matchingProducts.length > 5) {
      searchText += `... and ${matchingProducts.length - 5} more results`
    }

    await this.sendMessage(chatId, searchText)
  }

  private async handleStatusCommand(chatId: number): Promise<void> {
    const { products, orders } = this.shopData
    const currentTime = new Date().toLocaleString()

    const statusText = `🏪 *Shop Status Overview*

⏰ **Current Time:** ${currentTime}
🟢 **Status:** Online & Active

**📊 Quick Stats:**
• 📦 Products: ${products.length}
• 📋 Orders: ${orders.length}
• ⏳ Pending Orders: ${orders.filter((o) => o.status === "pending").length}
• 🏷️ Categories: ${this.shopData.categories.length}

**🤖 Bot Status:**
• ✅ Commands: Active
• ✅ Notifications: Enabled
• ✅ Order Processing: Ready

💡 Use /stats for detailed analytics
🔧 Use /help for all available commands`

    await this.sendMessage(chatId, statusText)
  }

  private async handleUnknownCommand(chatId: number, command: string): Promise<void> {
    const unknownText = `❌ Unknown command: \`${command}\`

🤖 I don't recognize that command. Here are some options:

**📋 Quick Commands:**
• /help - Show all commands
• /products - View products
• /orders - View orders
• /status - Shop status

💡 Type /help to see the complete list of available commands.`

    await this.sendMessage(chatId, unknownText)
  }

  // Additional helper methods for other commands...
  private async handleEditProductCommand(chatId: number, args: string[]): Promise<void> {
    if (args.length === 0) {
      await this.sendMessage(
        chatId,
        "❌ Please provide a product ID.\n\nUsage: /editproduct [id]\nExample: /editproduct 123",
      )
      return
    }

    const productId = args[0]
    const product = this.shopData.products.find((p) => p.id === productId)

    if (!product) {
      await this.sendMessage(chatId, `❌ Product with ID \`${productId}\` not found.`)
      return
    }

    const editText = `✏️ *Edit Product: ${product.name}*

Current details:
• Name: ${product.name}
• Price: ${product.price} ETH
• Stock: ${product.stock}
• Category: ${product.category}

⚠️ *Demo Mode:* In production, this would open an interactive editing interface.

💡 For now, use /deleteproduct ${productId} and /addproduct to replace the product.`

    await this.sendMessage(chatId, editText)
  }

  private async handleDeleteProductCommand(chatId: number, args: string[]): Promise<void> {
    if (args.length === 0) {
      await this.sendMessage(
        chatId,
        "❌ Please provide a product ID.\n\nUsage: /deleteproduct [id]\nExample: /deleteproduct 123",
      )
      return
    }

    const productId = args[0]
    const product = this.shopData.products.find((p) => p.id === productId)

    if (!product) {
      await this.sendMessage(chatId, `❌ Product with ID \`${productId}\` not found.`)
      return
    }

    const deleteText = `🗑️ *Delete Product Confirmation*

**Product to delete:**
• Name: ${product.name}
• Price: ${product.price} ETH
• Stock: ${product.stock} units

⚠️ *Demo Mode:* Product "${product.name}" would be permanently deleted from the database.

💡 In production, this would require confirmation and would be irreversible.`

    await this.sendMessage(chatId, deleteText)
  }

  private async handleOrderCommand(chatId: number, args: string[]): Promise<void> {
    if (args.length === 0) {
      await this.sendMessage(chatId, "❌ Please provide an order ID.\n\nUsage: /order [id]\nExample: /order 123")
      return
    }

    const orderId = args[0]
    const order = this.shopData.orders.find((o) => o.id === orderId)

    if (!order) {
      await this.sendMessage(chatId, `❌ Order #${orderId} not found.`)
      return
    }

    const statusEmoji =
      {
        pending: "⏳",
        processing: "🔄",
        completed: "✅",
        cancelled: "❌",
      }[order.status] || "❓"

    const orderText = `📋 *Order #${order.id} Details*

${statusEmoji} **Status:** ${order.status.toUpperCase()}
💰 **Total:** ${order.total} ETH
📅 **Date:** ${order.createdAt ? new Date(order.createdAt).toLocaleDateString() : "N/A"}

**📦 Items:**
${order.items.map((item) => `• ${item}`).join("\n")}

${
  order.customerInfo
    ? `**👤 Customer Info:**
${order.customerInfo.name ? `• Name: ${order.customerInfo.name}` : ""}
${order.customerInfo.email ? `• Email: ${order.customerInfo.email}` : ""}
${order.customerInfo.address ? `• Address: ${order.customerInfo.address}` : ""}`
    : ""
}

**🔧 Actions:**
• /updateorder ${order.id} [status] - Update status
• Valid statuses: pending, processing, completed, cancelled`

    await this.sendMessage(chatId, orderText)
  }

  private async handleUpdateOrderCommand(chatId: number, args: string[]): Promise<void> {
    if (args.length < 2) {
      await this.sendMessage(
        chatId,
        "❌ Usage: /updateorder [order_id] [status]\n\nValid statuses: pending, processing, completed, cancelled\nExample: /updateorder 123 completed",
      )
      return
    }

    const orderId = args[0]
    const newStatus = args[1].toLowerCase()
    const validStatuses = ["pending", "processing", "completed", "cancelled"]

    if (!validStatuses.includes(newStatus)) {
      await this.sendMessage(chatId, `❌ Invalid status "${newStatus}".\n\nValid statuses: ${validStatuses.join(", ")}`)
      return
    }

    const order = this.shopData.orders.find((o) => o.id === orderId)

    if (!order) {
      await this.sendMessage(chatId, `❌ Order #${orderId} not found.`)
      return
    }

    const statusEmoji =
      {
        pending: "⏳",
        processing: "🔄",
        completed: "✅",
        cancelled: "❌",
      }[newStatus] || "❓"

    const updateText = `${statusEmoji} *Order Status Updated*

**Order #${orderId}**
• Previous Status: ${order.status.toUpperCase()}
• New Status: ${newStatus.toUpperCase()}
• Total: ${order.total} ETH

⚠️ *Demo Mode:* Order status would be updated in the database.

💡 Customer would be notified of the status change.`

    await this.sendMessage(chatId, updateText)
  }

  private async handleCategoriesCommand(chatId: number): Promise<void> {
    const { categories } = this.shopData

    if (categories.length === 0) {
      await this.sendMessage(chatId, "🏷️ *No categories found.*\n\nUse /addcategory to create your first category!")
      return
    }

    let categoriesText = "🏷️ *Product Categories:*\n\n"

    categories.forEach((category, index) => {
      const productCount = this.shopData.products.filter(
        (p) => p.category === category.id || p.category === category.name,
      ).length

      categoriesText += `${index + 1}. *${category.name}*\n`
      categoriesText += `🆔 ID: \`${category.id}\`\n`
      categoriesText += `📦 Products: ${productCount}\n`

      if (category.description) {
        categoriesText += `📝 ${category.description}\n`
      }

      categoriesText += "\n"
    })

    categoriesText += "💡 Use /addcategory [name] to add a new category"

    await this.sendMessage(chatId, categoriesText)
  }

  private async handleAddCategoryCommand(chatId: number, args: string[]): Promise<void> {
    if (args.length === 0) {
      await this.sendMessage(
        chatId,
        '❌ Please provide a category name.\n\nUsage: /addcategory [name]\nExample: /addcategory "Digital Art"',
      )
      return
    }

    const categoryName = args.join(" ")

    // Check if category already exists
    const existingCategory = this.shopData.categories.find((c) => c.name.toLowerCase() === categoryName.toLowerCase())

    if (existingCategory) {
      await this.sendMessage(chatId, `❌ Category "${categoryName}" already exists.`)
      return
    }

    const newCategory = {
      id: Date.now().toString(),
      name: categoryName,
      description: `Category for ${categoryName} products`,
    }

    const successText = `✅ *Category Created Successfully!*

**${newCategory.name}**
🆔 ID: \`${newCategory.id}\`
📝 Description: ${newCategory.description}

⚠️ *Demo Mode:* Category would be saved to database in production.

💡 You can now use "${categoryName}" when adding products!`

    await this.sendMessage(chatId, successText)
  }
}
