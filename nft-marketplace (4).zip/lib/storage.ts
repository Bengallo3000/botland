// Storage utility for managing shop data and bot settings
export interface TelegramBotSettings {
  botToken: string
  botId: string
  groupId: string
  isEnabled: boolean
  webhookUrl?: string
  lastActivity?: Date
}

export interface ShopData {
  products: Product[]
  orders: Order[]
  categories: Category[]
  settings: ShopSettings
  telegramBot: TelegramBotSettings
}

export interface Product {
  id: string
  name: string
  price: number
  category: string
  image: string
  description: string
  stock: number
  createdAt: Date
  updatedAt: Date
}

export interface Order {
  id: string
  total: number
  status: "pending" | "processing" | "completed" | "cancelled"
  items: OrderItem[]
  customerInfo?: {
    name?: string
    email?: string
    address?: string
    telegramUserId?: number
  }
  paymentInfo?: {
    cryptoAddress: string
    currency: string
    txHash?: string
  }
  createdAt: Date
  updatedAt: Date
}

export interface OrderItem {
  productId: string
  productName: string
  quantity: number
  price: number
}

export interface Category {
  id: string
  name: string
  description?: string
  image?: string
  createdAt: Date
}

export interface ShopSettings {
  shopName: string
  slogan: string
  description: string
  headerBackground?: string
  bodyBackground?: string
  logo?: string
  cryptoAddresses: CryptoAddress[]
}

export interface CryptoAddress {
  currency: string
  address: string
}

export class ShopStorage {
  private static instance: ShopStorage
  private storageKey = "crypto-shop-data"

  private constructor() {}

  static getInstance(): ShopStorage {
    if (!ShopStorage.instance) {
      ShopStorage.instance = new ShopStorage()
    }
    return ShopStorage.instance
  }

  // Load all shop data from localStorage
  loadShopData(): ShopData {
    try {
      const stored = localStorage.getItem(this.storageKey)
      if (stored) {
        const data = JSON.parse(stored)
        return this.migrateData(data)
      }
    } catch (error) {
      console.error("Error loading shop data:", error)
    }

    return this.getDefaultShopData()
  }

  // Save all shop data to localStorage
  saveShopData(data: ShopData): void {
    try {
      const dataToSave = {
        ...data,
        lastUpdated: new Date().toISOString(),
      }
      localStorage.setItem(this.storageKey, JSON.stringify(dataToSave))
    } catch (error) {
      console.error("Error saving shop data:", error)
    }
  }

  // Get Telegram bot settings
  getTelegramBotSettings(): TelegramBotSettings {
    const data = this.loadShopData()
    return data.telegramBot
  }

  // Save Telegram bot settings
  saveTelegramBotSettings(settings: TelegramBotSettings): void {
    const data = this.loadShopData()
    data.telegramBot = {
      ...settings,
      lastActivity: new Date(),
    }
    this.saveShopData(data)
  }

  // Product management
  getProducts(): Product[] {
    const data = this.loadShopData()
    return data.products
  }

  addProduct(product: Omit<Product, "id" | "createdAt" | "updatedAt">): Product {
    const data = this.loadShopData()
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    data.products.push(newProduct)
    this.saveShopData(data)
    return newProduct
  }

  updateProduct(id: string, updates: Partial<Product>): Product | null {
    const data = this.loadShopData()
    const productIndex = data.products.findIndex((p) => p.id === id)

    if (productIndex === -1) return null

    data.products[productIndex] = {
      ...data.products[productIndex],
      ...updates,
      updatedAt: new Date(),
    }

    this.saveShopData(data)
    return data.products[productIndex]
  }

  deleteProduct(id: string): boolean {
    const data = this.loadShopData()
    const initialLength = data.products.length
    data.products = data.products.filter((p) => p.id !== id)

    if (data.products.length < initialLength) {
      this.saveShopData(data)
      return true
    }
    return false
  }

  // Order management
  getOrders(): Order[] {
    const data = this.loadShopData()
    return data.orders
  }

  addOrder(order: Omit<Order, "id" | "createdAt" | "updatedAt">): Order {
    const data = this.loadShopData()
    const newOrder: Order = {
      ...order,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    data.orders.push(newOrder)
    this.saveShopData(data)
    return newOrder
  }

  updateOrderStatus(id: string, status: Order["status"]): Order | null {
    const data = this.loadShopData()
    const orderIndex = data.orders.findIndex((o) => o.id === id)

    if (orderIndex === -1) return null

    data.orders[orderIndex] = {
      ...data.orders[orderIndex],
      status,
      updatedAt: new Date(),
    }

    this.saveShopData(data)
    return data.orders[orderIndex]
  }

  // Category management
  getCategories(): Category[] {
    const data = this.loadShopData()
    return data.categories
  }

  addCategory(category: Omit<Category, "id" | "createdAt">): Category {
    const data = this.loadShopData()
    const newCategory: Category = {
      ...category,
      id: Date.now().toString(),
      createdAt: new Date(),
    }
    data.categories.push(newCategory)
    this.saveShopData(data)
    return newCategory
  }

  deleteCategory(id: string): boolean {
    const data = this.loadShopData()
    const initialLength = data.categories.length
    data.categories = data.categories.filter((c) => c.id !== id)

    if (data.categories.length < initialLength) {
      this.saveShopData(data)
      return true
    }
    return false
  }

  // Shop settings
  getShopSettings(): ShopSettings {
    const data = this.loadShopData()
    return data.settings
  }

  updateShopSettings(settings: Partial<ShopSettings>): void {
    const data = this.loadShopData()
    data.settings = { ...data.settings, ...settings }
    this.saveShopData(data)
  }

  // Statistics and analytics
  getShopStats() {
    const data = this.loadShopData()

    const totalProducts = data.products.length
    const totalOrders = data.orders.length
    const pendingOrders = data.orders.filter((o) => o.status === "pending").length
    const completedOrders = data.orders.filter((o) => o.status === "completed").length
    const totalRevenue = data.orders.filter((o) => o.status === "completed").reduce((sum, o) => sum + o.total, 0)

    const lowStockProducts = data.products.filter((p) => p.stock < 5 && p.stock > 0).length
    const outOfStockProducts = data.products.filter((p) => p.stock === 0).length

    return {
      totalProducts,
      totalOrders,
      pendingOrders,
      completedOrders,
      totalRevenue,
      lowStockProducts,
      outOfStockProducts,
      averageOrderValue: completedOrders > 0 ? totalRevenue / completedOrders : 0,
      conversionRate: totalOrders > 0 ? (completedOrders / totalOrders) * 100 : 0,
    }
  }

  // Data migration for backward compatibility
  private migrateData(data: any): ShopData {
    // Ensure all required fields exist
    const migrated: ShopData = {
      products: data.products || [],
      orders: data.orders || [],
      categories: data.categories || [],
      settings: data.settings || this.getDefaultShopSettings(),
      telegramBot: data.telegramBot || this.getDefaultTelegramSettings(),
    }

    // Migrate products to include timestamps
    migrated.products = migrated.products.map((product) => ({
      ...product,
      createdAt: product.createdAt ? new Date(product.createdAt) : new Date(),
      updatedAt: product.updatedAt ? new Date(product.updatedAt) : new Date(),
    }))

    // Migrate orders to include timestamps
    migrated.orders = migrated.orders.map((order) => ({
      ...order,
      createdAt: order.createdAt ? new Date(order.createdAt) : new Date(),
      updatedAt: order.updatedAt ? new Date(order.updatedAt) : new Date(),
      items: Array.isArray(order.items)
        ? order.items.map((item) =>
            typeof item === "string" ? { productId: "", productName: item, quantity: 1, price: 0 } : item,
          )
        : [],
    }))

    // Migrate categories to include timestamps
    migrated.categories = migrated.categories.map((category) => ({
      ...category,
      createdAt: category.createdAt ? new Date(category.createdAt) : new Date(),
    }))

    return migrated
  }

  private getDefaultShopData(): ShopData {
    return {
      products: [],
      orders: [],
      categories: [
        { id: "1", name: "Brown", createdAt: new Date() },
        { id: "2", name: "Whites", createdAt: new Date() },
        { id: "3", name: "Drainers", createdAt: new Date() },
        { id: "4", name: "Leads", createdAt: new Date() },
        { id: "5", name: "Hallucinogenics", createdAt: new Date() },
      ],
      settings: this.getDefaultShopSettings(),
      telegramBot: this.getDefaultTelegramSettings(),
    }
  }

  private getDefaultShopSettings(): ShopSettings {
    return {
      shopName: "SUCHTKRUEPPELZAUNFABRIK.INFO",
      slogan: "Secure digital marketplace. Premium products with cryptocurrency payments only.",
      description:
        "DIVE INTO THE WORLD OF DIGITAL ART. EASILY CREATE, SELL, AND BUY NFTS WITH THE SECURITY AND TRANSPARENCY OF BLOCKCHAIN TECHNOLOGY.",
      headerBackground: "",
      bodyBackground: "",
      logo: "",
      cryptoAddresses: [
        { currency: "Bitcoin", address: "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa" },
        { currency: "Ethereum", address: "0x742d35Cc6634C0532925a3b8D4C9db96590c6C87" },
      ],
    }
  }

  private getDefaultTelegramSettings(): TelegramBotSettings {
    return {
      botToken: "",
      botId: "",
      groupId: "",
      isEnabled: false,
    }
  }

  // Export/Import functionality
  exportData(): string {
    const data = this.loadShopData()
    return JSON.stringify(data, null, 2)
  }

  importData(jsonData: string): boolean {
    try {
      const data = JSON.parse(jsonData)
      const migratedData = this.migrateData(data)
      this.saveShopData(migratedData)
      return true
    } catch (error) {
      console.error("Error importing data:", error)
      return false
    }
  }

  // Clear all data (for testing/reset)
  clearAllData(): void {
    localStorage.removeItem(this.storageKey)
  }
}

// Singleton instance
export const shopStorage = ShopStorage.getInstance()
