"use client"

import CryptoShop from "../crypto-shop"

export default function Page() {
  return <CryptoShop />
}
