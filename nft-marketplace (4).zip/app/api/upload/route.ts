import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get("file") as File
    const folder = (formData.get("folder") as string) || "general"

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    // Convert file to base64 for storage
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64 = buffer.toString("base64")
    const mimeType = file.type

    // Create a unique filename
    const timestamp = Date.now()
    const filename = `${folder}_${timestamp}_${file.name.replace(/[^a-zA-Z0-9.-]/g, "_")}`

    // Store in localStorage (in a real app, you'd use a proper file storage service)
    const imageData = {
      filename,
      data: `data:${mimeType};base64,${base64}`,
      originalName: file.name,
      size: file.size,
      type: mimeType,
      folder,
      uploadedAt: new Date().toISOString(),
    }

    return NextResponse.json({
      success: true,
      filename,
      url: imageData.data,
      data: imageData,
    })
  } catch (error) {
    console.error("Upload error:", error)
    return NextResponse.json({ error: "Upload failed" }, { status: 500 })
  }
}
