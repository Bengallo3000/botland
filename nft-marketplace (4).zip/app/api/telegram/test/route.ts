import { type NextRequest, NextResponse } from "next/server"
import { shopStorage } from "@/lib/storage"

export async function POST(request: NextRequest) {
  try {
    const { groupId } = await request.json()

    if (!groupId) {
      return NextResponse.json({ error: "Group ID is required" }, { status: 400 })
    }

    // Get bot settings from storage
    const botSettings = shopStorage.getTelegramBotSettings()

    if (!botSettings.botToken) {
      return NextResponse.json({ error: "Bot token not configured" }, { status: 400 })
    }

    // Get shop statistics for the test message
    const stats = shopStorage.getShopStats()
    const shopData = shopStorage.loadShopData()

    // Send comprehensive test message with shop status
    const message = `🤖 *Crypto Shop Bot Test - SUCCESS!*

✅ Bot is successfully connected and operational!

📊 *Current Shop Status:*
• 📦 Products: ${stats.totalProducts}
• 📋 Orders: ${stats.totalOrders} (${stats.pendingOrders} pending)
• 🏷️ Categories: ${shopData.categories.length}
• 💰 Revenue: ${stats.totalRevenue.toFixed(4)} ETH

🤖 *Bot Features:*
• ✅ Product Management
• ✅ Order Tracking  
• ✅ Real-time Notifications
• ✅ Analytics & Reports

📋 *Quick Commands:*
/help - Show all commands
/products - List products
/orders - View orders
/stats - Detailed statistics
/status - Shop status

🎯 *Ready to manage your crypto shop via Telegram!*

Type /help to see all available commands.`

    const response = await fetch(`https://api.telegram.org/bot${botSettings.botToken}/sendMessage`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: groupId,
        text: message,
        parse_mode: "Markdown",
      }),
    })

    const result = await response.json()

    if (!result.ok) {
      return NextResponse.json({ error: `Failed to send message: ${result.description}` }, { status: 400 })
    }

    // Update last activity in storage
    shopStorage.saveTelegramBotSettings({
      ...botSettings,
      lastActivity: new Date(),
    })

    return NextResponse.json({
      success: true,
      messageId: result.result.message_id,
      shopStats: stats,
    })
  } catch (error) {
    console.error("Error testing Telegram bot:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Test endpoint to verify bot configuration
export async function GET() {
  try {
    const botSettings = shopStorage.getTelegramBotSettings()
    const stats = shopStorage.getShopStats()

    const testResults = {
      botConfigured: !!botSettings.botToken,
      botEnabled: botSettings.isEnabled,
      groupConfigured: !!botSettings.groupId,
      webhookUrl: botSettings.webhookUrl,
      lastActivity: botSettings.lastActivity,
      shopStats: stats,
      testStatus: "ready",
    }

    // Test bot token if available
    if (botSettings.botToken) {
      try {
        const botInfoResponse = await fetch(`https://api.telegram.org/bot${botSettings.botToken}/getMe`)
        const botInfo = await botInfoResponse.json()

        testResults.testStatus = botInfo.ok ? "bot_valid" : "bot_invalid"
      } catch (error) {
        testResults.testStatus = "bot_error"
      }
    }

    return NextResponse.json(testResults)
  } catch (error) {
    console.error("Error in bot test endpoint:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
