import { type NextRequest, NextResponse } from "next/server"
import { shopStorage } from "@/lib/storage"

interface TelegramBotSettings {
  botToken: string
  botId: string
  groupId: string
  isEnabled: boolean
}

export async function POST(request: NextRequest) {
  try {
    const settings: TelegramBotSettings = await request.json()

    // Validate required fields
    if (!settings.botToken || !settings.groupId) {
      return NextResponse.json({ error: "Bot token and group ID are required" }, { status: 400 })
    }

    // Validate bot token format
    if (!settings.botToken.match(/^\d+:[A-Za-z0-9_-]+$/)) {
      return NextResponse.json({ error: "Invalid bot token format" }, { status: 400 })
    }

    // Test bot token by getting bot info
    const botInfoResponse = await fetch(`https://api.telegram.org/bot${settings.botToken}/getMe`)
    const botInfo = await botInfoResponse.json()

    if (!botInfo.ok) {
      return NextResponse.json({ error: "Invalid bot token" }, { status: 400 })
    }

    // Set webhook URL for the bot
    const webhookUrl = `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/api/telegram/webhook`
    const webhookResponse = await fetch(`https://api.telegram.org/bot${settings.botToken}/setWebhook`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ["message", "callback_query"],
      }),
    })

    const webhookResult = await webhookResponse.json()

    if (!webhookResult.ok) {
      console.error("Failed to set webhook:", webhookResult)
    }

    // Save settings to storage
    const botSettings = {
      ...settings,
      webhookUrl,
      lastActivity: new Date(),
    }

    shopStorage.saveTelegramBotSettings(botSettings)

    return NextResponse.json({
      success: true,
      botInfo: botInfo.result,
      webhook: webhookResult.ok ? "Webhook set successfully" : "Webhook setup failed",
      webhookUrl,
    })
  } catch (error) {
    console.error("Error setting up Telegram bot:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Get current bot settings
export async function GET() {
  try {
    const settings = shopStorage.getTelegramBotSettings()

    // Don't return sensitive token in GET request
    const safeSettings = {
      botId: settings.botId,
      groupId: settings.groupId,
      isEnabled: settings.isEnabled,
      webhookUrl: settings.webhookUrl,
      lastActivity: settings.lastActivity,
      hasToken: !!settings.botToken,
    }

    return NextResponse.json(safeSettings)
  } catch (error) {
    console.error("Error getting bot settings:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
