import { type NextRequest, NextResponse } from "next/server"
import { TelegramBotHandler } from "@/lib/telegram-bot"
import { shopStorage } from "@/lib/storage"

interface TelegramUpdate {
  update_id: number
  message?: {
    message_id: number
    from: {
      id: number
      is_bot: boolean
      first_name: string
      username?: string
    }
    chat: {
      id: number
      type: string
      title?: string
    }
    date: number
    text?: string
  }
  callback_query?: {
    id: string
    from: {
      id: number
      is_bot: boolean
      first_name: string
      username?: string
    }
    message: any
    data: string
  }
}

export async function POST(request: NextRequest) {
  try {
    const update: TelegramUpdate = await request.json()

    // Get bot settings from storage
    const botSettings = shopStorage.getTelegramBotSettings()

    if (!botSettings.isEnabled || !botSettings.botToken) {
      console.log("Bot is disabled or not configured")
      return NextResponse.json({ success: true })
    }

    // Get current shop data
    const shopData = shopStorage.loadShopData()

    // Create bot handler instance
    const botHandler = new TelegramBotHandler(botSettings.botToken, {
      products: shopData.products,
      orders: shopData.orders,
      categories: shopData.categories,
    })

    // Handle text messages
    if (update.message && update.message.text) {
      const message = update.message
      const chatId = message.chat.id
      const text = message.text.trim()

      // Log activity
      console.log(`[Telegram Bot] Message from ${message.from.first_name} (${message.from.id}): ${text}`)

      // Check if message is from authorized group/chat
      if (botSettings.groupId && chatId.toString() !== botSettings.groupId) {
        await botHandler.sendMessage(
          chatId,
          "❌ Unauthorized access. This bot is configured for a specific group only.",
        )
        return NextResponse.json({ success: true })
      }

      // Check if it's a command
      if (text.startsWith("/")) {
        const parts = text.split(" ")
        const command = parts[0].toLowerCase()
        const args = parts.slice(1)

        await botHandler.handleCommand(command, args, chatId)
      } else {
        // Handle non-command messages
        await botHandler.sendMessage(
          chatId,
          `👋 Hello ${message.from.first_name}! I'm your crypto shop bot.\n\nUse /help to see available commands.`,
        )
      }

      // Update last activity
      shopStorage.saveTelegramBotSettings({
        ...botSettings,
        lastActivity: new Date(),
      })
    }

    // Handle callback queries (inline keyboard buttons)
    if (update.callback_query) {
      const callbackQuery = update.callback_query
      const chatId = callbackQuery.message.chat.id

      // Answer the callback query to remove loading state
      await fetch(`https://api.telegram.org/bot${botSettings.botToken}/answerCallbackQuery`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          callback_query_id: callbackQuery.id,
          text: "Processing...",
        }),
      })

      // Handle the callback data
      const data = callbackQuery.data
      await botHandler.sendMessage(chatId, `Action: ${data}`)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error handling Telegram webhook:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// Handle GET requests (for webhook verification)
export async function GET() {
  const botSettings = shopStorage.getTelegramBotSettings()

  return NextResponse.json({
    status: "Telegram webhook endpoint is active",
    botEnabled: botSettings.isEnabled,
    lastActivity: botSettings.lastActivity,
  })
}
