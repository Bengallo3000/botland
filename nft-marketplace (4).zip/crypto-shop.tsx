"use client"

import Image from "next/image"
import { useEffect, useState, useRef } from "react"
import { ShoppingCart, Plus, Minus, X, Eye, EyeOff, Trash2, Edit } from "lucide-react"
import TelegramBotStatus from "./components/telegram-bot-status"
// Assuming ImageUpload and ImageGallery components are available in the same directory or imported correctly
// import ImageUpload from "./components/ImageUpload";
// import ImageGallery from "./components/ImageGallery";

interface Product {
  id: string
  name: string
  price: number
  category: string
  image: string
  description: string
  stock: number
}

interface Category {
  id: string
  name: string
  description?: string
  image?: string
}

interface ShopSettings {
  shopName: string
  slogan: string
  description: string
  headerBackground?: string
  bodyBackground?: string
  logo?: string
}

interface CryptoAddress {
  currency: string
  address: string
}

interface CartItem extends Product {
  quantity: number
}

// Added Telegram bot settings interface
interface TelegramBotSettings {
  botToken: string
  botId: string
  groupId: string
  isEnabled: boolean
}

// Added design settings interface
interface DesignSettings {
  primaryColor: string
  secondaryColor: string
  backgroundColor: string
  textColor: string
  borderColor: string
  buttonStyle: string
  fontFamily: string
  borderRadius: string
  layout: string
  headerStyle: string
  cardStyle: string
  animationSpeed: string
}

export default function CryptoShop() {
  const [scrollPosition, setScrollPosition] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)
  const [showAdmin, setShowAdmin] = useState(false)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [cart, setCart] = useState<CartItem[]>([])
  const [showCart, setShowCart] = useState(false)
  const [showCheckout, setShowCheckout] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState("all")

  // Admin states
  const [products, setProducts] = useState<Product[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [cryptoAddresses, setCryptoAddresses] = useState<CryptoAddress[]>([])
  const [activeAdminTab, setActiveAdminTab] = useState("products")
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [newProduct, setNewProduct] = useState<Partial<Product>>({})
  const [newCategory, setNewCategory] = useState("")
  const [newCryptoAddress, setNewCryptoAddress] = useState<CryptoAddress>({ currency: "", address: "" })

  const [shopSettings, setShopSettings] = useState<ShopSettings>({
    shopName: "SUCHTKRUEPPELZAUNFABRIK.INFO",
    slogan: "Secure digital marketplace. Premium products with cryptocurrency payments only.",
    description:
      "DIVE INTO THE WORLD OF DIGITAL ART. EASILY CREATE, SELL, AND BUY NFTS WITH THE SECURITY AND TRANSPARENCY OF BLOCKCHAIN TECHNOLOGY.",
    headerBackground: "",
    bodyBackground: "",
    logo: "",
  })
  const [editingCategory, setEditingCategory] = useState<Category | null>(null)
  const [newCategoryData, setNewCategoryData] = useState<Partial<Category>>({})

  const [telegramBotSettings, setTelegramBotSettings] = useState<TelegramBotSettings>({
    botToken: "",
    botId: "",
    groupId: "",
    isEnabled: false,
  })

  const [designSettings, setDesignSettings] = useState<DesignSettings>({
    primaryColor: "#a3ff12",
    secondaryColor: "#121212",
    backgroundColor: "#121212",
    textColor: "#ffffff",
    borderColor: "#a3ff12",
    buttonStyle: "angular",
    fontFamily: "system",
    borderRadius: "0px",
    layout: "grid",
    headerStyle: "minimal",
    cardStyle: "bordered",
    animationSpeed: "normal",
  })

  const [showImageGallery, setShowImageGallery] = useState(false)
  const [currentImageFolder, setCurrentImageFolder] = useState("products")

  const canvasRef = useRef<HTMLCanvasElement>(null)
  const keysPressed = useRef<Set<string>>(new Set())

  // Load data from localStorage
  useEffect(() => {
    const savedProducts = localStorage.getItem("crypto-shop-products")
    const savedCategories = localStorage.getItem("crypto-shop-categories")
    const savedCryptoAddresses = localStorage.getItem("crypto-shop-addresses")

    if (savedProducts) setProducts(JSON.parse(savedProducts))
    if (savedCategories) setCategories(JSON.parse(savedCategories))
    if (savedCryptoAddresses) setCryptoAddresses(JSON.parse(savedCryptoAddresses))

    const savedSettings = localStorage.getItem("crypto-shop-settings")
    if (savedSettings) setShopSettings(JSON.parse(savedSettings))

    // Default data if none exists
    if (!savedCategories) {
      const defaultCategories = [
        { id: "1", name: "Brown" },
        { id: "2", name: "Whites" },
        { id: "3", name: "Drainers" },
        { id: "4", name: "Leads" },
        { id: "5", name: "Hallucinogenics" },
      ]
      setCategories(defaultCategories)
      localStorage.setItem("crypto-shop-categories", JSON.stringify(defaultCategories))
    }

    if (!savedCryptoAddresses) {
      const defaultAddresses = [
        { currency: "Bitcoin", address: "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa" },
        { currency: "Ethereum", address: "0x742d35Cc6634C0532925a3b8D4C9db96590c6C87" },
      ]
      setCryptoAddresses(defaultAddresses)
      localStorage.setItem("crypto-shop-addresses", JSON.JSON.stringify(defaultAddresses))
    }

    // Load Telegram settings from localStorage
    const savedTelegramSettings = localStorage.getItem("crypto-shop-telegram")
    if (savedTelegramSettings) setTelegramBotSettings(JSON.parse(savedTelegramSettings))

    const savedDesignSettings = localStorage.getItem("crypto-shop-design")
    if (savedDesignSettings) setDesignSettings(JSON.parse(savedDesignSettings))
  }, [])

  // Save data to localStorage
  useEffect(() => {
    localStorage.setItem("crypto-shop-products", JSON.stringify(products))
  }, [products])

  useEffect(() => {
    localStorage.setItem("crypto-shop-categories", JSON.stringify(categories))
  }, [categories])

  useEffect(() => {
    localStorage.setItem("crypto-shop-addresses", JSON.stringify(cryptoAddresses))
  }, [cryptoAddresses])

  useEffect(() => {
    localStorage.setItem("crypto-shop-settings", JSON.stringify(shopSettings))
  }, [shopSettings])

  // Save Telegram settings to localStorage
  useEffect(() => {
    localStorage.setItem("crypto-shop-telegram", JSON.stringify(telegramBotSettings))
  }, [telegramBotSettings])

  useEffect(() => {
    localStorage.setItem("crypto-shop-design", JSON.stringify(designSettings))

    // Apply CSS custom properties for dynamic theming
    const root = document.documentElement
    root.style.setProperty("--primary-color", designSettings.primaryColor)
    root.style.setProperty("--secondary-color", designSettings.secondaryColor)
    root.style.setProperty("--background-color", designSettings.backgroundColor)
    root.style.setProperty("--text-color", designSettings.textColor)
    root.style.setProperty("--border-color", designSettings.borderColor)
    root.style.setProperty("--border-radius", designSettings.borderRadius)
  }, [designSettings])

  // Admin access key combination
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysPressed.current.add(e.key.toLowerCase())

      if (keysPressed.current.has("q") && keysPressed.current.has("ä")) {
        setShowAdmin(true)
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current.delete(e.key.toLowerCase())
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [])

  // Particle animation
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const particles: {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      alpha: number
    }[] = []

    const createParticles = () => {
      for (let i = 0; i < 50; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 2 + 0.5,
          speedX: Math.random() * 0.5 - 0.25,
          speedY: Math.random() * 0.5 - 0.25,
          alpha: Math.random() * 0.5 + 0.1,
        })
      }
    }

    const animateParticles = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i]
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(163, 255, 18, ${p.alpha})`
        ctx.fill()

        p.x += p.speedX
        p.y += p.speedY

        if (p.x > canvas.width) p.x = 0
        if (p.x < 0) p.x = canvas.width
        if (p.y > canvas.height) p.y = 0
        if (p.y < 0) p.y = canvas.height
      }

      requestAnimationFrame(animateParticles)
    }

    createParticles()
    animateParticles()

    const handleResize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  useEffect(() => {
    const handleScroll = () => setScrollPosition(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  // Admin functions
  const handleAdminLogin = () => {
    if (password === "admin123") {
      setIsAuthenticated(true)
      setPassword("")
    } else {
      alert("Invalid password!")
    }
  }

  const addProduct = () => {
    if (newProduct.name && newProduct.price && newProduct.category) {
      const product: Product = {
        id: Date.now().toString(),
        name: newProduct.name,
        price: newProduct.price,
        category: newProduct.category,
        image: newProduct.image || "/placeholder.svg?height=300&width=300&text=Product",
        description: newProduct.description || "",
        stock: newProduct.stock || 0,
      }
      setProducts([...products, product])
      setNewProduct({})
    }
  }

  const updateProduct = () => {
    if (editingProduct) {
      setProducts(products.map((p) => (p.id === editingProduct.id ? editingProduct : p)))
      setEditingProduct(null)
    }
  }

  const deleteProduct = (id: string) => {
    setProducts(products.filter((p) => p.id !== id))
  }

  const addCategory = () => {
    if (newCategoryData.name) {
      const category: Category = {
        id: Date.now().toString(),
        name: newCategoryData.name,
        description: newCategoryData.description || "",
        image: newCategoryData.image || "",
      }
      setCategories([...categories, category])
      setNewCategoryData({})
    }
  }

  const updateCategory = () => {
    if (editingCategory) {
      setCategories(categories.map((c) => (c.id === editingCategory.id ? editingCategory : c)))
      setEditingCategory(null)
    }
  }

  const deleteCategory = (id: string) => {
    setCategories(categories.filter((c) => c.id !== id))
  }

  const addCryptoAddress = () => {
    if (newCryptoAddress.currency && newCryptoAddress.address) {
      setCryptoAddresses([...cryptoAddresses, newCryptoAddress])
      setNewCryptoAddress({ currency: "", address: "" })
    }
  }

  const deleteCryptoAddress = (index: number) => {
    setCryptoAddresses(cryptoAddresses.filter((_, i) => i !== index))
  }

  // Cart functions
  const addToCart = (product: Product) => {
    const existingItem = cart.find((item) => item.id === product.id)
    if (existingItem) {
      setCart(cart.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)))
    } else {
      setCart([...cart, { ...product, quantity: 1 }])
    }
  }

  const removeFromCart = (id: string) => {
    setCart(cart.filter((item) => item.id !== id))
  }

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(id)
    } else {
      setCart(cart.map((item) => (item.id === id ? { ...item, quantity } : item)))
    }
  }

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  const filteredProducts =
    selectedCategory === "all" ? products : products.filter((p) => p.category === selectedCategory)

  const saveTelegramSettings = async () => {
    try {
      const response = await fetch("/api/telegram/setup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(telegramBotSettings),
      })

      if (response.ok) {
        alert("Telegram bot settings saved successfully!")
      } else {
        alert("Failed to save Telegram bot settings")
      }
    } catch (error) {
      console.error("Error saving Telegram settings:", error)
      alert("Error saving Telegram bot settings")
    }
  }

  const testTelegramBot = async () => {
    try {
      const response = await fetch("/api/telegram/test", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ groupId: telegramBotSettings.groupId }),
      })

      if (response.ok) {
        alert("Test message sent to Telegram group!")
      } else {
        alert("Failed to send test message")
      }
    } catch (error) {
      console.error("Error testing Telegram bot:", error)
      alert("Error testing Telegram bot")
    }
  }

  return (
    <div
      className="min-h-screen bg-[#121212] relative overflow-hidden"
      style={{
        backgroundColor: designSettings.backgroundColor,
        color: designSettings.textColor,
        fontFamily: designSettings.fontFamily,
      }}
    >
      <canvas ref={canvasRef} className="absolute inset-0 z-0 opacity-30 pointer-events-none" />

      {/* Green glow border effect */}
      <div className="absolute inset-0 border-[1px] border-[#a3ff12] shadow-[0_0_15px_#a3ff12] m-8 pointer-events-none"></div>

      {/* Corner brackets */}
      <div className="absolute top-6 left-6 w-12 h-12 border-t-2 border-l-2 border-[#a3ff12] shadow-[0_0_5px_#a3ff12] pointer-events-none"></div>
      <div className="absolute top-6 right-6 w-12 h-12 border-t-2 border-r-2 border-[#a3ff12] shadow-[0_0_5px_#a3ff12] pointer-events-none"></div>
      <div className="absolute bottom-6 left-6 w-12 h-12 border-b-2 border-l-2 border-[#a3ff12] shadow-[0_0_5px_#a3ff12] pointer-events-none"></div>
      <div className="absolute bottom-6 right-6 w-12 h-12 border-b-2 border-r-2 border-[#a3ff12] shadow-[0_0_5px_#a3ff12] pointer-events-none"></div>

      {/* Content container */}
      <div className="relative z-10 max-w-7xl mx-auto px-8 py-6">
        {/* Header */}
        <header className="flex justify-between items-center">
          <div
            className={`flex items-center transform transition-all duration-1000 ${isLoaded ? "translate-x-0 opacity-100" : "-translate-x-20 opacity-0"}`}
          >
            {shopSettings.logo ? (
              <Image
                src={shopSettings.logo || "/placeholder.svg"}
                alt="Shop Logo"
                width={32}
                height={32}
                className="mr-2 rounded"
              />
            ) : (
              <div className="w-6 h-6 rounded-full bg-[#a3ff12] flex items-center justify-center mr-2 animate-pulse">
                <div className="w-4 h-4 rounded-full border-2 border-black"></div>
              </div>
            )}
            <span className="text-[#a3ff12] font-bold">{shopSettings.shopName}</span>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowCart(true)}
              className="relative p-2 text-[#a3ff12] hover:bg-[#a3ff12] hover:bg-opacity-10 rounded transition-all"
            >
              <ShoppingCart size={24} />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#a3ff12] text-black text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cart.reduce((sum, item) => sum + item.quantity, 0)}
                </span>
              )}
            </button>
          </div>
        </header>

        {/* Hero Section */}
        <main className="mt-12">
          <div
            className={`text-center transform transition-all duration-1000 delay-300 ${isLoaded ? "translate-y-0 opacity-100" : "translate-y-20 opacity-0"}`}
          >
            <h1
              className="font-extrabold text-6xl md:text-7xl leading-none tracking-tighter"
              style={{ color: designSettings.primaryColor }}
            >
              {shopSettings.shopName.split(" ").map((word, index) => (
                <div key={index}>
                  {word}
                  <br />
                </div>
              ))}
            </h1>
            <p className="mt-8 text-lg max-w-2xl mx-auto" style={{ color: designSettings.textColor }}>
              {shopSettings.slogan}
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex justify-center mt-12 space-x-2">
            <button
              onClick={() => setSelectedCategory("all")}
              className={`px-4 py-2 text-sm font-semibold transition-all ${
                selectedCategory === "all"
                  ? "bg-[#a3ff12] text-black"
                  : "border border-[#a3ff12] text-[#a3ff12] hover:bg-[#a3ff12] hover:bg-opacity-10"
              }`}
              style={{ clipPath: "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" }}
            >
              ALL
            </button>
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 text-sm font-semibold transition-all ${
                  selectedCategory === category.id
                    ? "bg-[#a3ff12] text-black"
                    : "border border-[#a3ff12] text-[#a3ff12] hover:bg-[#a3ff12] hover:bg-opacity-10"
                }`}
                style={{ clipPath: "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" }}
              >
                {category.name.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {filteredProducts.map((product) => (
              <div
                key={product.id}
                className="border-2 shadow-[0_0_10px_#a3ff12] bg-black bg-opacity-50 rounded-lg overflow-hidden group hover:shadow-[0_0_20px_#a3ff12] transition-all duration-300"
                style={{ borderColor: designSettings.borderColor, backgroundColor: designSettings.backgroundColor }}
              >
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    width={300}
                    height={200}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-lg" style={{ color: designSettings.primaryColor }}>
                    {product.name}
                  </h3>
                  <p className="text-sm mt-2" style={{ color: designSettings.textColor }}>
                    {product.description}
                  </p>
                  <div className="flex justify-between items-center mt-4">
                    <span className="font-bold text-xl" style={{ color: designSettings.primaryColor }}>
                      ${product.price}
                    </span>
                    <span className="text-sm" style={{ color: designSettings.textColor }}>
                      Stock: {product.stock}
                    </span>
                  </div>
                  <button
                    onClick={() => addToCart(product)}
                    disabled={product.stock === 0}
                    className="w-full mt-4 px-4 py-2 font-bold hover:bg-opacity-90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    style={{
                      clipPath:
                        designSettings.buttonStyle === "angular" ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" : "none",
                      backgroundColor: designSettings.primaryColor,
                      color: designSettings.secondaryColor,
                      borderRadius: designSettings.borderRadius,
                    }}
                  >
                    {product.stock === 0 ? "OUT OF STOCK" : "ADD TO CART"}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </main>
      </div>

      {/* Cart Modal */}
      {showCart && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
          <div
            className="bg-[#121212] border-2 shadow-[0_0_20px_#a3ff12] rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto"
            style={{
              backgroundColor: designSettings.backgroundColor,
              borderColor: designSettings.borderColor,
              color: designSettings.textColor,
              fontFamily: designSettings.fontFamily,
            }}
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="font-bold text-2xl" style={{ color: designSettings.primaryColor }}>
                SHOPPING CART
              </h2>
              <button
                onClick={() => setShowCart(false)}
                className="hover:text-white transition-colors"
                style={{ color: designSettings.primaryColor }}
              >
                <X size={24} />
              </button>
            </div>

            {cart.length === 0 ? (
              <p className="text-center py-8">Your cart is empty</p>
            ) : (
              <>
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div key={item.id} className="border-b border-gray-700 pb-4">
                      <div className="flex items-center space-x-4">
                        <Image
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          width={60}
                          height={60}
                          className="rounded border border-[#a3ff12]"
                        />
                        <div>
                          <h3 className="font-semibold" style={{ color: designSettings.primaryColor }}>
                            {item.name}
                          </h3>
                          <p style={{ color: designSettings.textColor }}>${item.price}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          className="p-1 hover:bg-[#a3ff12] hover:bg-opacity-10 rounded"
                          style={{ color: designSettings.primaryColor }}
                        >
                          <Minus size={16} />
                        </button>
                        <span className="font-bold w-8 text-center" style={{ color: designSettings.primaryColor }}>
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 hover:bg-[#a3ff12] hover:bg-opacity-10 rounded"
                          style={{ color: designSettings.primaryColor }}
                        >
                          <Plus size={16} />
                        </button>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="p-1 text-red-500 hover:bg-red-500 hover:bg-opacity-10 rounded ml-2"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-6 pt-4 border-t border-gray-700">
                  <div className="flex justify-between items-center mb-4">
                    <span className="font-bold text-xl" style={{ color: designSettings.primaryColor }}>
                      TOTAL: ${getTotalPrice().toFixed(2)}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setShowCart(false)
                      setShowCheckout(true)
                    }}
                    className="w-full px-6 py-3 font-bold hover:bg-opacity-90 transition-all"
                    style={{
                      clipPath:
                        designSettings.buttonStyle === "angular" ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" : "none",
                      backgroundColor: designSettings.primaryColor,
                      color: designSettings.secondaryColor,
                      borderRadius: designSettings.borderRadius,
                    }}
                  >
                    PROCEED TO CHECKOUT
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Checkout Modal */}
      {showCheckout && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50">
          <div
            className="bg-[#121212] border-2 shadow-[0_0_20px_#a3ff12] rounded-lg p-6 max-w-2xl w-full mx-4 max-h-[80vh] overflow-y-auto"
            style={{
              backgroundColor: designSettings.backgroundColor,
              borderColor: designSettings.borderColor,
              color: designSettings.textColor,
              fontFamily: designSettings.fontFamily,
            }}
          >
            <div className="flex justify-between items-center mb-6">
              <h2 className="font-bold text-2xl" style={{ color: designSettings.primaryColor }}>
                CRYPTO CHECKOUT
              </h2>
              <button
                onClick={() => setShowCheckout(false)}
                className="hover:text-white transition-colors"
                style={{ color: designSettings.primaryColor }}
              >
                <X size={24} />
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                  Order Summary
                </h3>
                <div className="space-y-2">
                  {cart.map((item) => (
                    <div key={item.id} className="flex justify-between text-gray-400">
                      <span>
                        {item.name} x {item.quantity}
                      </span>
                      <span>${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                  <div
                    className="border-t border-gray-700 pt-2 flex justify-between font-bold"
                    style={{ color: designSettings.primaryColor }}
                  >
                    <span>TOTAL</span>
                    <span>${getTotalPrice().toFixed(2)}</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                  Payment Options
                </h3>
                <div className="space-y-4">
                  {cryptoAddresses.map((crypto, index) => (
                    <div
                      key={index}
                      className="border rounded p-4"
                      style={{
                        borderColor: designSettings.borderColor,
                        backgroundColor: designSettings.secondaryColor,
                      }}
                    >
                      <h4 className="font-semibold" style={{ color: designSettings.primaryColor }}>
                        {crypto.currency}
                      </h4>
                      <p className="text-sm mt-2" style={{ color: designSettings.textColor }}>
                        Send payment to:
                      </p>
                      <code
                        className="block p-2 rounded mt-2 text-sm break-all"
                        style={{ backgroundColor: designSettings.backgroundColor, color: designSettings.primaryColor }}
                      >
                        {crypto.address}
                      </code>
                    </div>
                  ))}
                </div>
              </div>

              <div className="text-center">
                <p className="text-sm mb-4" style={{ color: designSettings.textColor }}>
                  After sending payment, your order will be processed within 24 hours.
                </p>
                <button
                  onClick={() => {
                    alert("Order placed! Please send payment to one of the addresses above.")
                    setCart([])
                    setShowCheckout(false)
                  }}
                  className="px-6 py-3 font-bold hover:bg-opacity-90 transition-all"
                  style={{
                    clipPath:
                      designSettings.buttonStyle === "angular" ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" : "none",
                    backgroundColor: designSettings.primaryColor,
                    color: designSettings.secondaryColor,
                    borderRadius: designSettings.borderRadius,
                  }}
                >
                  CONFIRM ORDER
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Admin Modal */}
      {showAdmin && (
        <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50">
          <div
            className="bg-[#121212] border-2 shadow-[0_0_20px_#a3ff12] rounded-lg p-6 max-w-6xl w-full mx-4 max-h-[90vh] overflow-y-auto"
            style={{
              backgroundColor: designSettings.backgroundColor,
              borderColor: designSettings.borderColor,
              color: designSettings.textColor,
              fontFamily: designSettings.fontFamily,
            }}
          >
            {!isAuthenticated ? (
              <div className="text-center">
                <h2 className="font-bold text-2xl mb-6" style={{ color: designSettings.primaryColor }}>
                  ADMIN ACCESS
                </h2>
                <div className="max-w-md mx-auto">
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter admin password"
                      className="w-full px-4 py-3 bg-black border rounded focus:outline-none focus:shadow-[0_0_10px_#a3ff12]"
                      style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                      onKeyPress={(e) => e.key === "Enter" && handleAdminLogin()}
                    />
                    <button
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 hover:text-white"
                      style={{ color: designSettings.primaryColor }}
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                  <div className="flex space-x-4 mt-4">
                    <button
                      onClick={handleAdminLogin}
                      className="flex-1 px-4 py-2 font-bold hover:bg-opacity-90 transition-all"
                      style={{
                        clipPath:
                          designSettings.buttonStyle === "angular" ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" : "none",
                        backgroundColor: designSettings.primaryColor,
                        color: designSettings.secondaryColor,
                        borderRadius: designSettings.borderRadius,
                      }}
                    >
                      LOGIN
                    </button>
                    <button
                      onClick={() => {
                        setShowAdmin(false)
                        setPassword("")
                      }}
                      className="flex-1 px-4 py-2 border hover:bg-[#a3ff12] hover:bg-opacity-10 transition-all"
                      style={{
                        clipPath:
                          designSettings.buttonStyle === "angular" ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" : "none",
                        borderColor: designSettings.borderColor,
                        color: designSettings.primaryColor,
                        borderRadius: designSettings.borderRadius,
                      }}
                    >
                      CANCEL
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="font-bold text-2xl" style={{ color: designSettings.primaryColor }}>
                    ADMIN PANEL
                  </h2>
                  <button
                    onClick={() => {
                      setShowAdmin(false)
                      setIsAuthenticated(false)
                      setPassword("")
                    }}
                    className="hover:text-white transition-colors"
                    style={{ color: designSettings.primaryColor }}
                  >
                    <X size={24} />
                  </button>
                </div>

                {/* Admin Tabs */}
                <div className="flex space-x-2 mb-6 flex-wrap">
                  {["products", "categories", "crypto", "telegram", "images", "design", "settings"].map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveAdminTab(tab)}
                      className={`px-4 py-2 text-sm font-semibold transition-all mb-2 ${
                        activeAdminTab === tab
                          ? "bg-[#a3ff12] text-black"
                          : "border border-[#a3ff12] text-[#a3ff12] hover:bg-[#a3ff12] hover:bg-opacity-10"
                      }`}
                      style={{ clipPath: "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" }}
                    >
                      {tab.toUpperCase()}
                    </button>
                  ))}
                </div>

                {/* Products Tab */}
                {activeAdminTab === "products" && (
                  <div className="space-y-6">
                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        {editingProduct ? "Edit Product" : "Add New Product"}
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input
                          type="text"
                          placeholder="Product Name"
                          value={editingProduct ? editingProduct.name : newProduct.name || ""}
                          onChange={(e) =>
                            editingProduct
                              ? setEditingProduct({ ...editingProduct, name: e.target.value })
                              : setNewProduct({ ...newProduct, name: e.target.value })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <input
                          type="number"
                          placeholder="Price"
                          value={editingProduct ? editingProduct.price : newProduct.price || ""}
                          onChange={(e) =>
                            editingProduct
                              ? setEditingProduct({ ...editingProduct, price: Number.parseFloat(e.target.value) })
                              : setNewProduct({ ...newProduct, price: Number.parseFloat(e.target.value) })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <select
                          value={editingProduct ? editingProduct.category : newProduct.category || ""}
                          onChange={(e) =>
                            editingProduct
                              ? setEditingProduct({ ...editingProduct, category: e.target.value })
                              : setNewProduct({ ...newProduct, category: e.target.value })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        >
                          <option value="">Select Category</option>
                          {categories.map((cat) => (
                            <option key={cat.id} value={cat.id}>
                              {cat.name}
                            </option>
                          ))}
                        </select>
                        <input
                          type="number"
                          placeholder="Stock"
                          value={editingProduct ? editingProduct.stock : newProduct.stock || ""}
                          onChange={(e) =>
                            editingProduct
                              ? setEditingProduct({ ...editingProduct, stock: Number.parseInt(e.target.value) })
                              : setNewProduct({ ...newProduct, stock: Number.parseInt(e.target.value) })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <input
                          type="text"
                          placeholder="Image URL"
                          value={editingProduct ? editingProduct.image : newProduct.image || ""}
                          onChange={(e) =>
                            editingProduct
                              ? setEditingProduct({ ...editingProduct, image: e.target.value })
                              : setNewProduct({ ...newProduct, image: e.target.value })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12] md:col-span-2"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <textarea
                          placeholder="Description"
                          value={editingProduct ? editingProduct.description : newProduct.description || ""}
                          onChange={(e) =>
                            editingProduct
                              ? setEditingProduct({ ...editingProduct, description: e.target.value })
                              : setNewProduct({ ...newProduct, description: e.target.value })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12] md:col-span-2 h-20"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                      </div>
                      <div className="flex space-x-2 mt-4">
                        <button
                          onClick={editingProduct ? updateProduct : addProduct}
                          className="px-4 py-2 font-bold hover:bg-opacity-90 transition-all"
                          style={{
                            clipPath:
                              designSettings.buttonStyle === "angular"
                                ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)"
                                : "none",
                            backgroundColor: designSettings.primaryColor,
                            color: designSettings.secondaryColor,
                            borderRadius: designSettings.borderRadius,
                          }}
                        >
                          {editingProduct ? "UPDATE" : "ADD"} PRODUCT
                        </button>
                        {editingProduct && (
                          <button
                            onClick={() => setEditingProduct(null)}
                            className="px-4 py-2 border hover:bg-[#a3ff12] hover:bg-opacity-10 transition-all"
                            style={{
                              clipPath:
                                designSettings.buttonStyle === "angular"
                                  ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)"
                                  : "none",
                              borderColor: designSettings.borderColor,
                              color: designSettings.primaryColor,
                              borderRadius: designSettings.borderRadius,
                            }}
                          >
                            CANCEL
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Existing Products
                      </h3>
                      <div className="space-y-2 max-h-60 overflow-y-auto">
                        {products.map((product) => (
                          <div
                            key={product.id}
                            className="bg-black bg-opacity-50 p-3 rounded"
                            style={{ backgroundColor: designSettings.backgroundColor }}
                          >
                            <div>
                              <span className="font-semibold" style={{ color: designSettings.primaryColor }}>
                                {product.name}
                              </span>
                              <span className="ml-2" style={{ color: designSettings.textColor }}>
                                ${product.price}
                              </span>
                              <span className="ml-2" style={{ color: designSettings.textColor }}>
                                Stock: {product.stock}
                              </span>
                            </div>
                            <div className="flex space-x-2">
                              <button
                                onClick={() => setEditingProduct(product)}
                                className="p-1 hover:bg-[#a3ff12] hover:bg-opacity-10 rounded"
                                style={{ color: designSettings.primaryColor }}
                              >
                                <Edit size={16} />
                              </button>
                              <button
                                onClick={() => deleteProduct(product.id)}
                                className="p-1 text-red-500 hover:bg-red-500 hover:bg-opacity-10 rounded"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Categories Tab */}
                {activeAdminTab === "categories" && (
                  <div className="space-y-6">
                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        {editingCategory ? "Edit Category" : "Add New Category"}
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input
                          type="text"
                          placeholder="Category Name"
                          value={editingCategory ? editingCategory.name : newCategoryData.name || ""}
                          onChange={(e) =>
                            editingCategory
                              ? setEditingCategory({ ...editingCategory, name: e.target.value })
                              : setNewCategoryData({ ...newCategoryData, name: e.target.value })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <input
                          type="text"
                          placeholder="Category Image URL"
                          value={editingCategory ? editingCategory.image : newCategoryData.image || ""}
                          onChange={(e) =>
                            editingCategory
                              ? setEditingCategory({ ...editingCategory, image: e.target.value })
                              : setNewCategoryData({ ...newCategoryData, image: e.target.value })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <textarea
                          placeholder="Category Description"
                          value={editingCategory ? editingCategory.description : newCategoryData.description || ""}
                          onChange={(e) =>
                            editingCategory
                              ? setEditingCategory({ ...editingCategory, description: e.target.value })
                              : setNewCategoryData({ ...newCategoryData, description: e.target.value })
                          }
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12] md:col-span-2 h-20"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                      </div>
                      <div className="flex space-x-2 mt-4">
                        <button
                          onClick={editingCategory ? updateCategory : addCategory}
                          className="px-4 py-2 font-bold hover:bg-opacity-90 transition-all"
                          style={{
                            clipPath:
                              designSettings.buttonStyle === "angular"
                                ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)"
                                : "none",
                            backgroundColor: designSettings.primaryColor,
                            color: designSettings.secondaryColor,
                            borderRadius: designSettings.borderRadius,
                          }}
                        >
                          {editingCategory ? "UPDATE" : "ADD"} CATEGORY
                        </button>
                        {editingCategory && (
                          <button
                            onClick={() => setEditingCategory(null)}
                            className="px-4 py-2 border hover:bg-[#a3ff12] hover:bg-opacity-10 transition-all"
                            style={{
                              clipPath:
                                designSettings.buttonStyle === "angular"
                                  ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)"
                                  : "none",
                              borderColor: designSettings.borderColor,
                              color: designSettings.primaryColor,
                              borderRadius: designSettings.borderRadius,
                            }}
                          >
                            CANCEL
                          </button>
                        )}
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Existing Categories
                      </h3>
                      <div className="space-y-2">
                        {categories.map((category) => (
                          <div
                            key={category.id}
                            className="flex items-center justify-between bg-black bg-opacity-50 p-3 rounded"
                            style={{ backgroundColor: designSettings.backgroundColor }}
                          >
                            <div className="flex items-center space-x-3">
                              {category.image && (
                                <img
                                  src={category.image || "/placeholder.svg"}
                                  alt={category.name}
                                  className="w-8 h-8 rounded border border-[#a3ff12] object-cover"
                                />
                              )}
                              <div>
                                <span className="font-semibold" style={{ color: designSettings.primaryColor }}>
                                  {category.name}
                                </span>
                                {category.description && (
                                  <p className="text-sm" style={{ color: designSettings.textColor }}>
                                    {category.description}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <button
                                onClick={() => setEditingCategory(category)}
                                className="p-1 hover:bg-[#a3ff12] hover:bg-opacity-10 rounded"
                                style={{ color: designSettings.primaryColor }}
                              >
                                <Edit size={16} />
                              </button>
                              <button
                                onClick={() => deleteCategory(category.id)}
                                className="p-1 text-red-500 hover:bg-red-500 hover:bg-opacity-10 rounded"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Crypto Tab */}
                {activeAdminTab === "crypto" && (
                  <div className="space-y-6">
                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Add Crypto Address
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <input
                          type="text"
                          placeholder="Currency (e.g., Bitcoin)"
                          value={newCryptoAddress.currency}
                          onChange={(e) => setNewCryptoAddress({ ...newCryptoAddress, currency: e.target.value })}
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <input
                          type="text"
                          placeholder="Wallet Address"
                          value={newCryptoAddress.address}
                          onChange={(e) => setNewCryptoAddress({ ...newCryptoAddress, address: e.target.value })}
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <button
                          onClick={addCryptoAddress}
                          className="px-4 py-2 font-bold hover:bg-opacity-90 transition-all"
                          style={{
                            clipPath:
                              designSettings.buttonStyle === "angular"
                                ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)"
                                : "none",
                            backgroundColor: designSettings.primaryColor,
                            color: designSettings.secondaryColor,
                            borderRadius: designSettings.borderRadius,
                          }}
                        >
                          ADD
                        </button>
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Crypto Addresses
                      </h3>
                      <div className="space-y-3">
                        {cryptoAddresses.map((crypto, index) => (
                          <div
                            key={index}
                            className="p-4 rounded"
                            style={{ backgroundColor: designSettings.backgroundColor }}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-semibold" style={{ color: designSettings.primaryColor }}>
                                {crypto.currency}
                              </span>
                              <button
                                onClick={() => deleteCryptoAddress(index)}
                                className="p-1 text-red-500 hover:bg-red-500 hover:bg-opacity-10 rounded"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                            <code className="block text-sm break-all" style={{ color: designSettings.textColor }}>
                              {crypto.address}
                            </code>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Telegram Bot Tab */}
                {activeAdminTab === "telegram" && (
                  <div className="space-y-6">
                    <TelegramBotStatus />

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Telegram Bot Configuration
                      </h3>
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label
                              className="block text-sm font-semibold mb-2"
                              style={{ color: designSettings.primaryColor }}
                            >
                              Bot Token
                            </label>
                            <input
                              type="password"
                              placeholder="Enter your Telegram bot token"
                              value={telegramBotSettings.botToken}
                              onChange={(e) =>
                                setTelegramBotSettings({ ...telegramBotSettings, botToken: e.target.value })
                              }
                              className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                              style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                            />
                            <p className="text-xs mt-1" style={{ color: designSettings.textColor }}>
                              Get this from @BotFather on Telegram
                            </p>
                          </div>
                          <div>
                            <label
                              className="block text-sm font-semibold mb-2"
                              style={{ color: designSettings.primaryColor }}
                            >
                              Bot ID
                            </label>
                            <input
                              type="text"
                              placeholder="Enter bot ID (e.g., @yourbot)"
                              value={telegramBotSettings.botId}
                              onChange={(e) =>
                                setTelegramBotSettings({ ...telegramBotSettings, botId: e.target.value })
                              }
                              className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                              style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                            />
                          </div>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Group/Channel ID
                          </label>
                          <input
                            type="text"
                            placeholder="Enter Telegram group/channel ID (e.g., -1001234567890)"
                            value={telegramBotSettings.groupId}
                            onChange={(e) =>
                              setTelegramBotSettings({ ...telegramBotSettings, groupId: e.target.value })
                            }
                            className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                            style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                          />
                          <p className="text-xs mt-1" style={{ color: designSettings.textColor }}>
                            Add your bot to the group and get the group ID
                          </p>
                        </div>

                        <div className="flex items-center space-x-3">
                          <input
                            type="checkbox"
                            id="enableBot"
                            checked={telegramBotSettings.isEnabled}
                            onChange={(e) =>
                              setTelegramBotSettings({ ...telegramBotSettings, isEnabled: e.target.checked })
                            }
                            className="w-4 h-4 text-[#a3ff12] bg-black border-[#a3ff12] rounded focus:ring-[#a3ff12]"
                          />
                          <label
                            htmlFor="enableBot"
                            className="font-semibold"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Enable Telegram Bot
                          </label>
                        </div>

                        <div className="flex space-x-4">
                          <button
                            onClick={saveTelegramSettings}
                            className="px-6 py-2 font-bold hover:bg-opacity-90 transition-all"
                            style={{
                              clipPath:
                                designSettings.buttonStyle === "angular"
                                  ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)"
                                  : "none",
                              backgroundColor: designSettings.primaryColor,
                              color: designSettings.secondaryColor,
                              borderRadius: designSettings.borderRadius,
                            }}
                          >
                            SAVE SETTINGS
                          </button>
                          <button
                            onClick={testTelegramBot}
                            disabled={!telegramBotSettings.botToken || !telegramBotSettings.groupId}
                            className="px-6 py-2 border hover:bg-[#a3ff12] hover:bg-opacity-10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                            style={{
                              clipPath:
                                designSettings.buttonStyle === "angular"
                                  ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)"
                                  : "none",
                              borderColor: designSettings.borderColor,
                              color: designSettings.primaryColor,
                              borderRadius: designSettings.borderRadius,
                            }}
                          >
                            TEST BOT
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Bot Commands
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <h4 className="font-semibold text-sm" style={{ color: designSettings.primaryColor }}>
                            Product Management:
                          </h4>
                          <div className="text-sm space-y-1" style={{ color: designSettings.textColor }}>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/products</code> - List all products
                            </p>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/addproduct</code> - Add new product
                            </p>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/editproduct [id]</code> - Edit
                              product
                            </p>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/deleteproduct [id]</code> - Delete
                              product
                            </p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-semibold text-sm" style={{ color: designSettings.primaryColor }}>
                            Order Management:
                          </h4>
                          <div className="text-sm space-y-1" style={{ color: designSettings.textColor }}>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/orders</code> - List all orders
                            </p>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/order [id]</code> - View order
                              details
                            </p>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/updateorder [id]</code> - Update
                              order status
                            </p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-semibold text-sm" style={{ color: designSettings.primaryColor }}>
                            Categories:
                          </h4>
                          <div className="text-sm space-y-1" style={{ color: designSettings.textColor }}>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/categories</code> - List categories
                            </p>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/addcategory</code> - Add category
                            </p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <h4 className="font-semibold text-sm" style={{ color: designSettings.primaryColor }}>
                            General:
                          </h4>
                          <div className="text-sm space-y-1" style={{ color: designSettings.textColor }}>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/help</code> - Show all commands
                            </p>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/status</code> - Shop status
                            </p>
                            <p>
                              <code className="bg-black bg-opacity-50 px-1 rounded">/stats</code> - Shop statistics
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Setup Instructions
                      </h3>
                      <div className="space-y-3 text-sm" style={{ color: designSettings.textColor }}>
                        <div className="flex items-start space-x-2">
                          <span className="font-bold" style={{ color: designSettings.primaryColor }}>
                            1.
                          </span>
                          <p>Create a new bot by messaging @BotFather on Telegram and use /newbot command</p>
                        </div>
                        <div className="flex items-start space-x-2">
                          <span className="font-bold" style={{ color: designSettings.primaryColor }}>
                            2.
                          </span>
                          <p>Copy the bot token and paste it in the "Bot Token" field above</p>
                        </div>
                        <div className="flex items-start space-x-2">
                          <span className="font-bold" style={{ color: designSettings.primaryColor }}>
                            3.
                          </span>
                          <p>Add your bot to your Telegram group or channel</p>
                        </div>
                        <div className="flex items-start space-x-2">
                          <span className="font-bold" style={{ color: designSettings.primaryColor }}>
                            4.
                          </span>
                          <p>Get the group/channel ID (you can use @userinfobot or check browser developer tools)</p>
                        </div>
                        <div className="flex items-start space-x-2">
                          <span className="font-bold" style={{ color: designSettings.primaryColor }}>
                            5.
                          </span>
                          <p>Enable the bot and test the connection</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Images Tab */}
                {activeAdminTab === "images" && (
                  <div className="space-y-6">
                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Image Management
                      </h3>

                      {/* Image Category Selector */}
                      <div className="flex space-x-2 mb-6 flex-wrap">
                        {["products", "categories", "design", "info", "contact"].map((folder) => (
                          <button
                            key={folder}
                            onClick={() => setCurrentImageFolder(folder)}
                            className={`px-3 py-1 text-sm font-semibold transition-all mb-2 ${
                              currentImageFolder === folder
                                ? "bg-[#a3ff12] text-black"
                                : "border border-[#a3ff12] text-[#a3ff12] hover:bg-[#a3ff12] hover:bg-opacity-10"
                            }`}
                            style={{ clipPath: "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" }}
                          >
                            {folder.toUpperCase()}
                          </button>
                        ))}
                      </div>

                      {/* Upload Section */}
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div>
                          {/* Assuming ImageUpload component is available and correctly imported */}
                          {/* <ImageUpload
                            folder={currentImageFolder}
                            onImageUploaded={(url, filename) => {
                              // Refresh gallery
                              window.location.reload()
                            }}
                            label={`Upload ${currentImageFolder} Image`}
                          /> */}
                          <p className="text-gray-400">Image upload component placeholder.</p>
                        </div>

                        <div
                          className="border border-gray-600 rounded p-4"
                          style={{ backgroundColor: designSettings.backgroundColor }}
                        >
                          <h4 className="font-semibold mb-2" style={{ color: designSettings.primaryColor }}>
                            Usage Tips:
                          </h4>
                          <ul className="text-sm space-y-1" style={{ color: designSettings.textColor }}>
                            <li>
                              • <strong>Products:</strong> Product photos, thumbnails
                            </li>
                            <li>
                              • <strong>Categories:</strong> Category banners, icons
                            </li>
                            <li>
                              • <strong>Design:</strong> Backgrounds, logos, decorative elements
                            </li>
                            <li>
                              • <strong>Info:</strong> About page images, team photos
                            </li>
                            <li>
                              • <strong>Contact:</strong> Location images, contact graphics
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>

                    {/* Image Gallery */}
                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      {/* Assuming ImageGallery component is available and correctly imported */}
                      {/* <ImageGallery 
                        folder={currentImageFolder}
                        showSelectButton={true}
                        onImageSelect={(url) => {
                          // Copy URL to clipboard
                          navigator.clipboard.writeText(url)
                          alert('Image URL copied to clipboard!')
                        }}
                      /> */}
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Image Gallery Placeholder
                      </h3>
                      <p className="text-gray-400">Image gallery component placeholder.</p>
                    </div>
                  </div>
                )}

                {/* Design Tab */}
                {activeAdminTab === "design" && (
                  <div className="space-y-6">
                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Color Scheme
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Primary Color
                          </label>
                          <div className="flex space-x-2">
                            <input
                              type="color"
                              value={designSettings.primaryColor}
                              onChange={(e) => setDesignSettings({ ...designSettings, primaryColor: e.target.value })}
                              className="w-12 h-10 border border-[#a3ff12] rounded cursor-pointer"
                            />
                            <input
                              type="text"
                              value={designSettings.primaryColor}
                              onChange={(e) => setDesignSettings({ ...designSettings, primaryColor: e.target.value })}
                              className="flex-1 px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                              style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                            />
                          </div>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Background Color
                          </label>
                          <div className="flex space-x-2">
                            <input
                              type="color"
                              value={designSettings.backgroundColor}
                              onChange={(e) =>
                                setDesignSettings({ ...designSettings, backgroundColor: e.target.value })
                              }
                              className="w-12 h-10 border border-[#a3ff12] rounded cursor-pointer"
                            />
                            <input
                              type="text"
                              value={designSettings.backgroundColor}
                              onChange={(e) =>
                                setDesignSettings({ ...designSettings, backgroundColor: e.target.value })
                              }
                              className="flex-1 px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                              style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                            />
                          </div>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Text Color
                          </label>
                          <div className="flex space-x-2">
                            <input
                              type="color"
                              value={designSettings.textColor}
                              onChange={(e) => setDesignSettings({ ...designSettings, textColor: e.target.value })}
                              className="w-12 h-10 border border-[#a3ff12] rounded cursor-pointer"
                            />
                            <input
                              type="text"
                              value={designSettings.textColor}
                              onChange={(e) => setDesignSettings({ ...designSettings, textColor: e.target.value })}
                              className="flex-1 px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                              style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                            />
                          </div>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Border Color
                          </label>
                          <div className="flex space-x-2">
                            <input
                              type="color"
                              value={designSettings.borderColor}
                              onChange={(e) => setDesignSettings({ ...designSettings, borderColor: e.target.value })}
                              className="w-12 h-10 border border-[#a3ff12] rounded cursor-pointer"
                            />
                            <input
                              type="text"
                              value={designSettings.borderColor}
                              onChange={(e) => setDesignSettings({ ...designSettings, borderColor: e.target.value })}
                              className="flex-1 px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                              style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Typography & Layout
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Font Family
                          </label>
                          <select
                            value={designSettings.fontFamily}
                            onChange={(e) => setDesignSettings({ ...designSettings, fontFamily: e.target.value })}
                            className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                            style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                          >
                            <option value="system">System Default</option>
                            <option value="serif">Serif</option>
                            <option value="mono">Monospace</option>
                            <option value="cursive">Cursive</option>
                            <option value="fantasy">Fantasy</option>
                          </select>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Border Radius
                          </label>
                          <select
                            value={designSettings.borderRadius}
                            onChange={(e) => setDesignSettings({ ...designSettings, borderRadius: e.target.value })}
                            className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                            style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                          >
                            <option value="0px">Sharp (0px)</option>
                            <option value="4px">Small (4px)</option>
                            <option value="8px">Medium (8px)</option>
                            <option value="12px">Large (12px)</option>
                            <option value="20px">Extra Large (20px)</option>
                            <option value="50%">Rounded (50%)</option>
                          </select>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Layout Style
                          </label>
                          <select
                            value={designSettings.layout}
                            onChange={(e) => setDesignSettings({ ...designSettings, layout: e.target.value })}
                            className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                            style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                          >
                            <option value="grid">Grid Layout</option>
                            <option value="list">List Layout</option>
                            <option value="masonry">Masonry Layout</option>
                            <option value="carousel">Carousel Layout</option>
                          </select>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Animation Speed
                          </label>
                          <select
                            value={designSettings.animationSpeed}
                            onChange={(e) => setDesignSettings({ ...designSettings, animationSpeed: e.target.value })}
                            className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                            style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                          >
                            <option value="slow">Slow</option>
                            <option value="normal">Normal</option>
                            <option value="fast">Fast</option>
                            <option value="none">No Animation</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Component Styles
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Button Style
                          </label>
                          <select
                            value={designSettings.buttonStyle}
                            onChange={(e) => setDesignSettings({ ...designSettings, buttonStyle: e.target.value })}
                            className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                            style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                          >
                            <option value="angular">Angular (Current)</option>
                            <option value="rounded">Rounded</option>
                            <option value="pill">Pill Shape</option>
                            <option value="minimal">Minimal</option>
                          </select>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Header Style
                          </label>
                          <select
                            value={designSettings.headerStyle}
                            onChange={(e) => setDesignSettings({ ...designSettings, headerStyle: e.target.value })}
                            className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                            style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                          >
                            <option value="minimal">Minimal</option>
                            <option value="bold">Bold</option>
                            <option value="gradient">Gradient</option>
                            <option value="glass">Glass Effect</option>
                          </select>
                        </div>

                        <div>
                          <label
                            className="block text-sm font-semibold mb-2"
                            style={{ color: designSettings.primaryColor }}
                          >
                            Card Style
                          </label>
                          <select
                            value={designSettings.cardStyle}
                            onChange={(e) => setDesignSettings({ ...designSettings, cardStyle: e.target.value })}
                            className="w-full px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                            style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                          >
                            <option value="bordered">Bordered (Current)</option>
                            <option value="shadow">Shadow</option>
                            <option value="flat">Flat</option>
                            <option value="elevated">Elevated</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Design Presets
                      </h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <button
                          onClick={() =>
                            setDesignSettings({
                              primaryColor: "#a3ff12",
                              secondaryColor: "#121212",
                              backgroundColor: "#121212",
                              textColor: "#ffffff",
                              borderColor: "#a3ff12",
                              buttonStyle: "angular",
                              fontFamily: "system",
                              borderRadius: "0px",
                              layout: "grid",
                              headerStyle: "minimal",
                              cardStyle: "bordered",
                              animationSpeed: "normal",
                            })
                          }
                          className="p-4 border rounded hover:bg-[#a3ff12] hover:bg-opacity-10 transition-all"
                          style={{ borderColor: designSettings.borderColor }}
                        >
                          <div className="font-semibold mb-2" style={{ color: designSettings.primaryColor }}>
                            Cyber Green (Default)
                          </div>
                          <div className="flex space-x-2">
                            <div className="w-4 h-4 bg-[#a3ff12] rounded"></div>
                            <div className="w-4 h-4 bg-[#121212] border border-gray-600 rounded"></div>
                          </div>
                        </button>

                        <button
                          onClick={() =>
                            setDesignSettings({
                              ...designSettings,
                              primaryColor: "#ff6b6b",
                              backgroundColor: "#1a1a1a",
                              borderColor: "#ff6b6b",
                              buttonStyle: "rounded",
                              borderRadius: "8px",
                            })
                          }
                          className="p-4 border rounded hover:bg-[#a3ff12] hover:bg-opacity-10 transition-all"
                          style={{ borderColor: designSettings.borderColor }}
                        >
                          <div className="font-semibold mb-2" style={{ color: designSettings.primaryColor }}>
                            Neon Red
                          </div>
                          <div className="flex space-x-2">
                            <div className="w-4 h-4 bg-[#ff6b6b] rounded"></div>
                            <div className="w-4 h-4 bg-[#1a1a1a] border border-gray-600 rounded"></div>
                          </div>
                        </button>

                        <button
                          onClick={() =>
                            setDesignSettings({
                              ...designSettings,
                              primaryColor: "#4ecdc4",
                              backgroundColor: "#2c3e50",
                              borderColor: "#4ecdc4",
                              buttonStyle: "pill",
                              borderRadius: "12px",
                            })
                          }
                          className="p-4 border rounded hover:bg-[#a3ff12] hover:bg-opacity-10 transition-all"
                          style={{ borderColor: designSettings.borderColor }}
                        >
                          <div className="font-semibold mb-2" style={{ color: designSettings.primaryColor }}>
                            Ocean Blue
                          </div>
                          <div className="flex space-x-2">
                            <div className="w-4 h-4 bg-[#4ecdc4] rounded"></div>
                            <div className="w-4 h-4 bg-[#2c3e50] border border-gray-600 rounded"></div>
                          </div>
                        </button>
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Preview
                      </h3>
                      <div
                        className="p-4 rounded"
                        style={{
                          backgroundColor: designSettings.backgroundColor,
                          color: designSettings.textColor,
                          borderColor: designSettings.borderColor,
                          fontFamily: designSettings.fontFamily,
                          borderRadius: designSettings.borderRadius,
                        }}
                      >
                        <div
                          className="border-2 p-4 rounded"
                          style={{
                            borderColor: designSettings.borderColor,
                            borderRadius: designSettings.borderRadius,
                          }}
                        >
                          <h4 style={{ color: designSettings.primaryColor }}>Sample Product Card</h4>
                          <p className="text-sm mt-2">
                            This is how your products will look with the current design settings.
                          </p>
                          <button
                            className="mt-3 px-4 py-2 font-bold transition-all"
                            style={{
                              backgroundColor: designSettings.primaryColor,
                              color: designSettings.secondaryColor,
                              borderRadius: designSettings.borderRadius,
                              clipPath:
                                designSettings.buttonStyle === "angular"
                                  ? "polygon(0 0, 100% 0, 95% 100%, 5% 100%)"
                                  : "none",
                            }}
                          >
                            ADD TO CART
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Settings Tab */}
                {activeAdminTab === "settings" && (
                  <div className="space-y-6">
                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Shop Settings
                      </h3>
                      <div className="grid grid-cols-1 gap-4">
                        <input
                          type="text"
                          placeholder="Shop Name"
                          value={shopSettings.shopName}
                          onChange={(e) => setShopSettings({ ...shopSettings, shopName: e.target.value })}
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <input
                          type="text"
                          placeholder="Logo URL"
                          value={shopSettings.logo || ""}
                          onChange={(e) => setShopSettings({ ...shopSettings, logo: e.target.value })}
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <textarea
                          placeholder="Slogan"
                          value={shopSettings.slogan}
                          onChange={(e) => setShopSettings({ ...shopSettings, slogan: e.target.value })}
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12] h-20"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <textarea
                          placeholder="Description"
                          value={shopSettings.description}
                          onChange={(e) => setShopSettings({ ...shopSettings, description: e.target.value })}
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12] h-24"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                      </div>
                    </div>

                    <div className="border rounded p-4" style={{ borderColor: designSettings.borderColor }}>
                      <h3 className="font-semibold mb-4" style={{ color: designSettings.primaryColor }}>
                        Background Images
                      </h3>
                      <div className="grid grid-cols-1 gap-4">
                        <input
                          type="text"
                          placeholder="Header Background Image URL"
                          value={shopSettings.headerBackground || ""}
                          onChange={(e) => setShopSettings({ ...shopSettings, headerBackground: e.target.value })}
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                        <input
                          type="text"
                          placeholder="Body Background Image URL"
                          value={shopSettings.bodyBackground || ""}
                          onChange={(e) => setShopSettings({ ...shopSettings, bodyBackground: e.target.value })}
                          className="px-3 py-2 bg-black border rounded focus:outline-none focus:shadow-[0_0_5px_#a3ff12]"
                          style={{ borderColor: designSettings.borderColor, color: designSettings.textColor }}
                        />
                      </div>
                      {(shopSettings.headerBackground || shopSettings.bodyBackground) && (
                        <div className="mt-4">
                          <h4 className="font-semibold mb-2" style={{ color: designSettings.primaryColor }}>
                            Preview:
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {shopSettings.headerBackground && (
                              <div className="border rounded p-2" style={{ borderColor: designSettings.borderColor }}>
                                <p className="text-sm mb-2" style={{ color: designSettings.textColor }}>
                                  Header Background:
                                </p>
                                <img
                                  src={shopSettings.headerBackground || "/placeholder.svg"}
                                  alt="Header Background"
                                  className="w-full h-20 object-cover rounded"
                                />
                              </div>
                            )}
                            {shopSettings.bodyBackground && (
                              <div className="border rounded p-2" style={{ borderColor: designSettings.borderColor }}>
                                <p className="text-sm mb-2" style={{ color: designSettings.textColor }}>
                                  Body Background:
                                </p>
                                <img
                                  src={shopSettings.bodyBackground || "/placeholder.svg"}
                                  alt="Body Background"
                                  className="w-full h-20 object-cover rounded"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
