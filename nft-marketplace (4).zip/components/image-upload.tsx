"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Upload, X } from "lucide-react"

interface ImageUploadProps {
  folder: string
  onImageUploaded: (imageUrl: string, filename: string) => void
  currentImage?: string
  label?: string
  accept?: string
}

export default function ImageUpload({
  folder,
  onImageUploaded,
  currentImage,
  label = "Upload Image",
  accept = "image/*",
}: ImageUploadProps) {
  const [uploading, setUploading] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileUpload = async (file: File) => {
    if (!file) return

    setUploading(true)
    try {
      const formData = new FormData()
      formData.append("file", file)
      formData.append("folder", folder)

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      })

      if (response.ok) {
        const result = await response.json()

        // Store image data in localStorage for persistence
        const existingImages = JSON.parse(localStorage.getItem(`shop-images-${folder}`) || "[]")
        existingImages.push(result.data)
        localStorage.setItem(`shop-images-${folder}`, JSON.stringify(existingImages))

        onImageUploaded(result.url, result.filename)
      } else {
        alert("Upload failed")
      }
    } catch (error) {
      console.error("Upload error:", error)
      alert("Upload failed")
    } finally {
      setUploading(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)

    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileUpload(files[0])
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      handleFileUpload(files[0])
    }
  }

  const removeImage = () => {
    onImageUploaded("", "")
  }

  return (
    <div className="space-y-2">
      <label className="block text-[#a3ff12] text-sm font-semibold">{label}</label>

      {currentImage ? (
        <div className="relative border-2 border-[#a3ff12] rounded-lg overflow-hidden">
          <img src={currentImage || "/placeholder.svg"} alt="Uploaded" className="w-full h-32 object-cover" />
          <button
            onClick={removeImage}
            className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
          >
            <X size={16} />
          </button>
        </div>
      ) : (
        <div
          className={`border-2 border-dashed rounded-lg p-6 text-center transition-all cursor-pointer ${
            dragOver ? "border-[#a3ff12] bg-[#a3ff12] bg-opacity-10" : "border-gray-600 hover:border-[#a3ff12]"
          }`}
          onDrop={handleDrop}
          onDragOver={(e) => {
            e.preventDefault()
            setDragOver(true)
          }}
          onDragLeave={() => setDragOver(false)}
          onClick={() => fileInputRef.current?.click()}
        >
          {uploading ? (
            <div className="flex flex-col items-center space-y-2">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#a3ff12]"></div>
              <p className="text-gray-400 text-sm">Uploading...</p>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-2">
              <Upload className="h-8 w-8 text-gray-400" />
              <p className="text-gray-400 text-sm">Drop image here or click to browse</p>
              <p className="text-gray-500 text-xs">Supports: JPG, PNG, GIF, WebP</p>
            </div>
          )}
        </div>
      )}

      <input ref={fileInputRef} type="file" accept={accept} onChange={handleFileSelect} className="hidden" />
    </div>
  )
}
