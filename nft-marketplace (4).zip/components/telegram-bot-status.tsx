"use client"

import { useEffect, useState } from "react"
import { CheckCircle, XCircle, Clock, AlertCircle } from "lucide-react"

interface BotStatus {
  botConfigured: boolean
  botEnabled: boolean
  groupConfigured: boolean
  webhookUrl?: string
  lastActivity?: string
  shopStats: {
    totalProducts: number
    totalOrders: number
    pendingOrders: number
    totalRevenue: number
  }
  testStatus: "ready" | "bot_valid" | "bot_invalid" | "bot_error"
}

export default function TelegramBotStatus() {
  const [status, setStatus] = useState<BotStatus | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchStatus = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/telegram/test")

      if (!response.ok) {
        throw new Error("Failed to fetch bot status")
      }

      const data = await response.json()
      setStatus(data)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchStatus()

    // Refresh status every 30 seconds
    const interval = setInterval(fetchStatus, 30000)
    return () => clearInterval(interval)
  }, [])

  if (loading) {
    return (
      <div className="border border-[#a3ff12] rounded p-4 bg-black bg-opacity-50">
        <div className="flex items-center space-x-2">
          <Clock className="text-[#a3ff12] animate-spin" size={16} />
          <span className="text-[#a3ff12]">Checking bot status...</span>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="border border-red-500 rounded p-4 bg-red-500 bg-opacity-10">
        <div className="flex items-center space-x-2">
          <XCircle className="text-red-500" size={16} />
          <span className="text-red-500">Error: {error}</span>
        </div>
      </div>
    )
  }

  if (!status) return null

  const getStatusIcon = () => {
    if (!status.botConfigured) return <XCircle className="text-red-500" size={16} />
    if (!status.botEnabled) return <AlertCircle className="text-yellow-500" size={16} />
    if (status.testStatus === "bot_valid") return <CheckCircle className="text-[#a3ff12]" size={16} />
    return <XCircle className="text-red-500" size={16} />
  }

  const getStatusText = () => {
    if (!status.botConfigured) return "Not Configured"
    if (!status.botEnabled) return "Disabled"
    if (status.testStatus === "bot_valid") return "Active"
    if (status.testStatus === "bot_invalid") return "Invalid Token"
    if (status.testStatus === "bot_error") return "Connection Error"
    return "Unknown"
  }

  const getStatusColor = () => {
    if (!status.botConfigured || status.testStatus === "bot_invalid" || status.testStatus === "bot_error") {
      return "border-red-500 bg-red-500 bg-opacity-10"
    }
    if (!status.botEnabled) {
      return "border-yellow-500 bg-yellow-500 bg-opacity-10"
    }
    if (status.testStatus === "bot_valid") {
      return "border-[#a3ff12] bg-[#a3ff12] bg-opacity-10"
    }
    return "border-gray-500 bg-gray-500 bg-opacity-10"
  }

  return (
    <div className={`border rounded p-4 ${getStatusColor()}`}>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {getStatusIcon()}
            <span className="text-[#a3ff12] font-semibold">Bot Status: {getStatusText()}</span>
          </div>
          <button
            onClick={fetchStatus}
            className="text-xs px-2 py-1 border border-[#a3ff12] text-[#a3ff12] rounded hover:bg-[#a3ff12] hover:bg-opacity-10 transition-all"
          >
            Refresh
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-gray-400">Configuration:</span>
            <div className="space-y-1 mt-1">
              <div className="flex items-center space-x-2">
                {status.botConfigured ? (
                  <CheckCircle className="text-[#a3ff12]" size={12} />
                ) : (
                  <XCircle className="text-red-500" size={12} />
                )}
                <span className="text-gray-300">Bot Token</span>
              </div>
              <div className="flex items-center space-x-2">
                {status.groupConfigured ? (
                  <CheckCircle className="text-[#a3ff12]" size={12} />
                ) : (
                  <XCircle className="text-red-500" size={12} />
                )}
                <span className="text-gray-300">Group ID</span>
              </div>
              <div className="flex items-center space-x-2">
                {status.webhookUrl ? (
                  <CheckCircle className="text-[#a3ff12]" size={12} />
                ) : (
                  <XCircle className="text-red-500" size={12} />
                )}
                <span className="text-gray-300">Webhook</span>
              </div>
            </div>
          </div>

          <div>
            <span className="text-gray-400">Shop Stats:</span>
            <div className="space-y-1 mt-1 text-gray-300">
              <div>📦 Products: {status.shopStats.totalProducts}</div>
              <div>📋 Orders: {status.shopStats.totalOrders}</div>
              <div>⏳ Pending: {status.shopStats.pendingOrders}</div>
              <div>💰 Revenue: {status.shopStats.totalRevenue.toFixed(4)} ETH</div>
            </div>
          </div>
        </div>

        {status.lastActivity && (
          <div className="text-xs text-gray-400">Last Activity: {new Date(status.lastActivity).toLocaleString()}</div>
        )}

        {status.webhookUrl && <div className="text-xs text-gray-400">Webhook: {status.webhookUrl}</div>}
      </div>
    </div>
  )
}
