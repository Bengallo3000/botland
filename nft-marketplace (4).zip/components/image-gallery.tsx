"use client"

import { useState, useEffect } from "react"
import { Trash2, Eye } from "lucide-react"

interface ImageData {
  filename: string
  data: string
  originalName: string
  size: number
  type: string
  folder: string
  uploadedAt: string
}

interface ImageGalleryProps {
  folder: string
  onImageSelect?: (imageUrl: string) => void
  showSelectButton?: boolean
}

export default function ImageGallery({ folder, onImageSelect, showSelectButton = false }: ImageGalleryProps) {
  const [images, setImages] = useState<ImageData[]>([])
  const [selectedImage, setSelectedImage] = useState<string | null>(null)

  useEffect(() => {
    loadImages()
  }, [folder])

  const loadImages = () => {
    const storedImages = JSON.parse(localStorage.getItem(`shop-images-${folder}`) || "[]")
    setImages(storedImages)
  }

  const deleteImage = (filename: string) => {
    const updatedImages = images.filter((img) => img.filename !== filename)
    setImages(updatedImages)
    localStorage.setItem(`shop-images-${folder}`, JSON.stringify(updatedImages))
  }

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return "0 Bytes"
    const k = 1024
    const sizes = ["Bytes", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
  }

  return (
    <div className="space-y-4">
      <h4 className="text-[#a3ff12] font-semibold">
        {folder.charAt(0).toUpperCase() + folder.slice(1)} Images ({images.length})
      </h4>

      {images.length === 0 ? (
        <p className="text-gray-400 text-sm text-center py-8">No images uploaded yet</p>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {images.map((image) => (
            <div
              key={image.filename}
              className="border border-[#a3ff12] rounded-lg overflow-hidden bg-black bg-opacity-50"
            >
              <div className="relative">
                <img
                  src={image.data || "/placeholder.svg"}
                  alt={image.originalName}
                  className="w-full h-24 object-cover cursor-pointer hover:opacity-80 transition-opacity"
                  onClick={() => setSelectedImage(image.data)}
                />
                <div className="absolute top-1 right-1 flex space-x-1">
                  <button
                    onClick={() => setSelectedImage(image.data)}
                    className="p-1 bg-black bg-opacity-70 text-[#a3ff12] rounded hover:bg-opacity-90 transition-all"
                  >
                    <Eye size={12} />
                  </button>
                  <button
                    onClick={() => deleteImage(image.filename)}
                    className="p-1 bg-black bg-opacity-70 text-red-500 rounded hover:bg-opacity-90 transition-all"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
              <div className="p-2">
                <p className="text-[#a3ff12] text-xs font-semibold truncate">{image.originalName}</p>
                <p className="text-gray-400 text-xs">{formatFileSize(image.size)}</p>
                {showSelectButton && onImageSelect && (
                  <button
                    onClick={() => onImageSelect(image.data)}
                    className="w-full mt-2 px-2 py-1 bg-[#a3ff12] text-black text-xs font-bold hover:bg-opacity-90 transition-all"
                    style={{ clipPath: "polygon(0 0, 100% 0, 95% 100%, 5% 100%)" }}
                  >
                    SELECT
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Image Preview Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50"
          onClick={() => setSelectedImage(null)}
        >
          <div className="max-w-4xl max-h-[90vh] relative">
            <img
              src={selectedImage || "/placeholder.svg"}
              alt="Preview"
              className="max-w-full max-h-full object-contain"
            />
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-4 right-4 p-2 bg-black bg-opacity-70 text-white rounded-full hover:bg-opacity-90 transition-all"
            >
              <Eye size={20} />
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
